self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2f302bf9f17b1fa54d2aa843c5c6ff25",
    "url": "/index.html"
  },
  {
    "revision": "17c0e25c0baaf439a5b2",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "008b0100ee878cc24c68",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "708982f2ecb639ea12dc",
    "url": "/static/css/14.f5002e05.chunk.css"
  },
  {
    "revision": "ce24660a57e1f60beabb",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "c20788e2df4bb74ce697",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "17c0e25c0baaf439a5b2",
    "url": "/static/js/0.9d97fa2d.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.9d97fa2d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "20d2fa6e1184a9eae39c",
    "url": "/static/js/1.2fc5a47b.chunk.js"
  },
  {
    "revision": "3507ee8995f01eaa54bf",
    "url": "/static/js/10.65a97c38.chunk.js"
  },
  {
    "revision": "008b0100ee878cc24c68",
    "url": "/static/js/13.e0f692d9.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.e0f692d9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "708982f2ecb639ea12dc",
    "url": "/static/js/14.b87a7499.chunk.js"
  },
  {
    "revision": "ce24660a57e1f60beabb",
    "url": "/static/js/15.840a55c7.chunk.js"
  },
  {
    "revision": "1188bb76c383b78dcd04",
    "url": "/static/js/16.21223b0c.chunk.js"
  },
  {
    "revision": "c4b17d48b1e5677a4701",
    "url": "/static/js/17.a7d466d4.chunk.js"
  },
  {
    "revision": "b26a055586f234686ac7",
    "url": "/static/js/18.5a88085f.chunk.js"
  },
  {
    "revision": "e4f29a4155e9e7f9fbd6",
    "url": "/static/js/19.b876b05f.chunk.js"
  },
  {
    "revision": "f0ed900588bcf3cff594",
    "url": "/static/js/2.87b8b8a9.chunk.js"
  },
  {
    "revision": "b92542d72ca7d2723225",
    "url": "/static/js/20.b6035f8b.chunk.js"
  },
  {
    "revision": "5c8175ebf195ea77c3ed",
    "url": "/static/js/21.14f7edd4.chunk.js"
  },
  {
    "revision": "5fdf7e1777e77d3c11af",
    "url": "/static/js/22.64f9cf21.chunk.js"
  },
  {
    "revision": "8fbb28c0e716f0aa5421",
    "url": "/static/js/23.fff2ccb1.chunk.js"
  },
  {
    "revision": "5e8c4c6c2f4fc6bb0106",
    "url": "/static/js/24.65c68851.chunk.js"
  },
  {
    "revision": "5849c929dfa5bfa54d51",
    "url": "/static/js/25.11b368c5.chunk.js"
  },
  {
    "revision": "e23e5c436ae8cec74eeb",
    "url": "/static/js/26.01a86e86.chunk.js"
  },
  {
    "revision": "be8d49f05ec2ee7e5d75",
    "url": "/static/js/27.9e41440d.chunk.js"
  },
  {
    "revision": "e31710d9beccff97401e",
    "url": "/static/js/28.573529eb.chunk.js"
  },
  {
    "revision": "2de13a5d76e760372e61",
    "url": "/static/js/29.d40c4bd9.chunk.js"
  },
  {
    "revision": "076e22ab2f51f08ade7f",
    "url": "/static/js/3.7c60f2ee.chunk.js"
  },
  {
    "revision": "9266ce5eb0fefb8d5d6c",
    "url": "/static/js/30.f888c1da.chunk.js"
  },
  {
    "revision": "601b1695c7942cd04789",
    "url": "/static/js/31.b9e04330.chunk.js"
  },
  {
    "revision": "0e401f3b251b9ed8d7c2",
    "url": "/static/js/32.922aa29b.chunk.js"
  },
  {
    "revision": "2bdf3bb883a72b6cc9f4",
    "url": "/static/js/33.c4d01881.chunk.js"
  },
  {
    "revision": "63f9fce9f9aeb7d1c0c0",
    "url": "/static/js/34.c5c2253d.chunk.js"
  },
  {
    "revision": "a09ecfe45f0605ff75e4",
    "url": "/static/js/35.c7b22ea9.chunk.js"
  },
  {
    "revision": "d4513e07c9d5a0c7369c",
    "url": "/static/js/36.a15c9712.chunk.js"
  },
  {
    "revision": "8f5108eff2bdb57ea019",
    "url": "/static/js/37.c1606118.chunk.js"
  },
  {
    "revision": "0fa9bc5f35db76ede2ae",
    "url": "/static/js/38.bc54d1b6.chunk.js"
  },
  {
    "revision": "602df46ac15d70fcb1d3",
    "url": "/static/js/39.06d8a41b.chunk.js"
  },
  {
    "revision": "4f5a0be2f464596c9ce7",
    "url": "/static/js/4.7a262303.chunk.js"
  },
  {
    "revision": "c8020ffbfe9f0f4c3a2e",
    "url": "/static/js/40.7af9bc86.chunk.js"
  },
  {
    "revision": "80c1ada366cc374484e8",
    "url": "/static/js/41.f086daaa.chunk.js"
  },
  {
    "revision": "adf313e20d78d6aff55b",
    "url": "/static/js/42.b2b0ab8a.chunk.js"
  },
  {
    "revision": "01214879c0ac0866fbdd",
    "url": "/static/js/43.5a838551.chunk.js"
  },
  {
    "revision": "13b8faa8cfe0a10a538c",
    "url": "/static/js/44.ed129823.chunk.js"
  },
  {
    "revision": "e0b2f6832299e3a14ec8",
    "url": "/static/js/45.68676227.chunk.js"
  },
  {
    "revision": "7042128186ada2938c5b",
    "url": "/static/js/46.d94c16b5.chunk.js"
  },
  {
    "revision": "b059203eefe1c38f5ef4",
    "url": "/static/js/47.56067275.chunk.js"
  },
  {
    "revision": "9445843157d2e5703a74",
    "url": "/static/js/48.f88eb9ba.chunk.js"
  },
  {
    "revision": "9c473823543761bdf551",
    "url": "/static/js/49.45709cfe.chunk.js"
  },
  {
    "revision": "1c837b4664458c4ed832",
    "url": "/static/js/5.7e29d666.chunk.js"
  },
  {
    "revision": "dc568ae590416c8c9e51",
    "url": "/static/js/50.78ebae8e.chunk.js"
  },
  {
    "revision": "bdc2cec32b10fbdf027f",
    "url": "/static/js/51.ae49a367.chunk.js"
  },
  {
    "revision": "e38299281f95e30145b6",
    "url": "/static/js/52.130359b1.chunk.js"
  },
  {
    "revision": "21f5b16c06e5d5eb9395",
    "url": "/static/js/53.09b07bb2.chunk.js"
  },
  {
    "revision": "352c518f9301c7d1c31f",
    "url": "/static/js/54.a86f5c19.chunk.js"
  },
  {
    "revision": "7d699dc3d96ee883b0f7",
    "url": "/static/js/55.5af4898a.chunk.js"
  },
  {
    "revision": "0e6addbecaa18c19d0c1",
    "url": "/static/js/56.3fdb738b.chunk.js"
  },
  {
    "revision": "afc5d05ed1fc9dd092ae",
    "url": "/static/js/57.75a6eef6.chunk.js"
  },
  {
    "revision": "4fd2c7aefa471a23390c",
    "url": "/static/js/58.44e0947c.chunk.js"
  },
  {
    "revision": "d6ca5c2d27ea6524c5a4",
    "url": "/static/js/59.c0aecc32.chunk.js"
  },
  {
    "revision": "faa68b66286857ec297a",
    "url": "/static/js/6.66f9084f.chunk.js"
  },
  {
    "revision": "e5f731773bfefc3dbf04",
    "url": "/static/js/60.7e9b63ad.chunk.js"
  },
  {
    "revision": "c60019673ee5be4dc781",
    "url": "/static/js/61.171dbb7c.chunk.js"
  },
  {
    "revision": "f8da5bbaca7ec259548a",
    "url": "/static/js/62.c9cda000.chunk.js"
  },
  {
    "revision": "12a78b83dbcdb2593d9d",
    "url": "/static/js/63.1fc22364.chunk.js"
  },
  {
    "revision": "1e67a21c654f66060106",
    "url": "/static/js/64.8e5ba1ca.chunk.js"
  },
  {
    "revision": "cc3a1082288b17d4caa0",
    "url": "/static/js/65.50ef1738.chunk.js"
  },
  {
    "revision": "ca034e5c193460b4552c",
    "url": "/static/js/66.d54742a6.chunk.js"
  },
  {
    "revision": "5004783b49763e1d39d5",
    "url": "/static/js/67.59fa3b71.chunk.js"
  },
  {
    "revision": "b288f965fd377b529382",
    "url": "/static/js/68.dc697eb5.chunk.js"
  },
  {
    "revision": "da73aed8afc66f77eb80",
    "url": "/static/js/69.8014f8e0.chunk.js"
  },
  {
    "revision": "b6f9482f25a969c47bdc",
    "url": "/static/js/7.6039b39d.chunk.js"
  },
  {
    "revision": "a0e6947c4f28f93ae909",
    "url": "/static/js/70.8de15986.chunk.js"
  },
  {
    "revision": "577a1589ee19d22a7056",
    "url": "/static/js/71.74c5cc0d.chunk.js"
  },
  {
    "revision": "30e73776f0acd735e4a5",
    "url": "/static/js/72.3e757092.chunk.js"
  },
  {
    "revision": "8863154dc8fa7b712efa",
    "url": "/static/js/73.a9fd2d52.chunk.js"
  },
  {
    "revision": "e29dbaef4a4c09d7521e",
    "url": "/static/js/74.74ae005c.chunk.js"
  },
  {
    "revision": "66d0f62db7367ea7449a",
    "url": "/static/js/75.7eda2bde.chunk.js"
  },
  {
    "revision": "627b76417bad6db3a234",
    "url": "/static/js/76.4bf3e6e6.chunk.js"
  },
  {
    "revision": "4daa6cc96a3c3aece3e4",
    "url": "/static/js/77.2145869d.chunk.js"
  },
  {
    "revision": "ebacebad0869e979673b",
    "url": "/static/js/78.323fa3d4.chunk.js"
  },
  {
    "revision": "02c002f358df358a527a",
    "url": "/static/js/79.2f604115.chunk.js"
  },
  {
    "revision": "f0fc1e6134b746ff7253",
    "url": "/static/js/8.ba6d388e.chunk.js"
  },
  {
    "revision": "b04babf9fde68bc33039",
    "url": "/static/js/80.84d2a1c1.chunk.js"
  },
  {
    "revision": "9480dd6f347e4fd8e6a8",
    "url": "/static/js/81.721dcc6a.chunk.js"
  },
  {
    "revision": "a74fa39b01696cba2908",
    "url": "/static/js/82.c496d19b.chunk.js"
  },
  {
    "revision": "922ee1fc94e0c200ae27",
    "url": "/static/js/83.0afeb948.chunk.js"
  },
  {
    "revision": "cecaa6fc6e3212c82311",
    "url": "/static/js/84.618cecc1.chunk.js"
  },
  {
    "revision": "4f8f511b6e836adf7fbe",
    "url": "/static/js/9.4ef4cdc6.chunk.js"
  },
  {
    "revision": "c20788e2df4bb74ce697",
    "url": "/static/js/main.e4490065.chunk.js"
  },
  {
    "revision": "5b0e0b04f7b71a318dd7",
    "url": "/static/js/runtime-main.a43abc87.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);