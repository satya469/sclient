self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "28dd45debf2fb4d811215291a15c844e",
    "url": "/index.html"
  },
  {
    "revision": "372bf8222d7e05c67f35",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "c37a70ae0e6e2550a9c8",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "40c6f30e8f52132d2ae4",
    "url": "/static/css/14.2749b44f.chunk.css"
  },
  {
    "revision": "52eef7eba7d88f0f9900",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "037a7c54fd03479ca6a5",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "372bf8222d7e05c67f35",
    "url": "/static/js/0.acb8b90b.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.acb8b90b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ff96738934e9207d93e7",
    "url": "/static/js/1.4fde8921.chunk.js"
  },
  {
    "revision": "c37a70ae0e6e2550a9c8",
    "url": "/static/js/12.f84c802a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.f84c802a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5724ab5db7e5a9a381ce",
    "url": "/static/js/13.fb6a9e3f.chunk.js"
  },
  {
    "revision": "40c6f30e8f52132d2ae4",
    "url": "/static/js/14.b7bfadb3.chunk.js"
  },
  {
    "revision": "52eef7eba7d88f0f9900",
    "url": "/static/js/15.d8520139.chunk.js"
  },
  {
    "revision": "def74ffa2e761b54a273",
    "url": "/static/js/16.c64d37de.chunk.js"
  },
  {
    "revision": "b5029eb09524312a1cd3",
    "url": "/static/js/17.4d73e74f.chunk.js"
  },
  {
    "revision": "ef36a6aa18ff350d5e8b",
    "url": "/static/js/18.5bb30687.chunk.js"
  },
  {
    "revision": "94fe1d97dbd0dcabaf2e",
    "url": "/static/js/19.3d76d1d6.chunk.js"
  },
  {
    "revision": "1beb0707459e6487408f",
    "url": "/static/js/2.fb4749a1.chunk.js"
  },
  {
    "revision": "169444821f163c679b48",
    "url": "/static/js/20.5e58d717.chunk.js"
  },
  {
    "revision": "e8b11653f9ac7364a306",
    "url": "/static/js/21.7274a7d6.chunk.js"
  },
  {
    "revision": "bb6e48f0f5d6e1e14a99",
    "url": "/static/js/22.0d547998.chunk.js"
  },
  {
    "revision": "088f4fd1a7a395b216b3",
    "url": "/static/js/23.56fdd970.chunk.js"
  },
  {
    "revision": "46bf6073b7063035358c",
    "url": "/static/js/24.8382e8e8.chunk.js"
  },
  {
    "revision": "c88975b6704a59d2e069",
    "url": "/static/js/25.af0b5ccb.chunk.js"
  },
  {
    "revision": "9be98153c74627733e59",
    "url": "/static/js/26.8c8dec36.chunk.js"
  },
  {
    "revision": "de8264c72bc1eca1438d",
    "url": "/static/js/27.2c8bf7cb.chunk.js"
  },
  {
    "revision": "420832061ce5321485da",
    "url": "/static/js/28.cf9fea32.chunk.js"
  },
  {
    "revision": "06a9b405aa50e24081f6",
    "url": "/static/js/29.bce8d3d8.chunk.js"
  },
  {
    "revision": "5a0abd48e8f72657f05e",
    "url": "/static/js/3.2f87a858.chunk.js"
  },
  {
    "revision": "3557fdd204c82d1e2214",
    "url": "/static/js/30.c96297a6.chunk.js"
  },
  {
    "revision": "22355eaa667cc81bc03c",
    "url": "/static/js/31.5f2a639f.chunk.js"
  },
  {
    "revision": "5523e01da22509298020",
    "url": "/static/js/32.b1b6b678.chunk.js"
  },
  {
    "revision": "c998e28d5bbdd5ae352d",
    "url": "/static/js/33.0df85a9d.chunk.js"
  },
  {
    "revision": "ee26d05cd3f547c944f1",
    "url": "/static/js/34.475f10c0.chunk.js"
  },
  {
    "revision": "085f9a5fc83d2009d1da",
    "url": "/static/js/35.d68eff85.chunk.js"
  },
  {
    "revision": "b00fe9f7ec629c787306",
    "url": "/static/js/36.0a8edf96.chunk.js"
  },
  {
    "revision": "6e8ea3b9608acbfa763c",
    "url": "/static/js/37.79fcaadd.chunk.js"
  },
  {
    "revision": "5ab355b2b59ccc244f94",
    "url": "/static/js/38.77a71ac9.chunk.js"
  },
  {
    "revision": "d5485413ff1e29cdab45",
    "url": "/static/js/39.caa95714.chunk.js"
  },
  {
    "revision": "73880260bd82fcfa8147",
    "url": "/static/js/4.c4c8b020.chunk.js"
  },
  {
    "revision": "5e3325d0b20fe1aeab14",
    "url": "/static/js/40.6e3bcbe6.chunk.js"
  },
  {
    "revision": "8799431ef2a65d67e775",
    "url": "/static/js/41.d60ca872.chunk.js"
  },
  {
    "revision": "a849996e957bd386afe0",
    "url": "/static/js/42.12e5dd58.chunk.js"
  },
  {
    "revision": "d024cf404d5644bc4d37",
    "url": "/static/js/43.90d3c235.chunk.js"
  },
  {
    "revision": "974644e3ea6ba1b497d5",
    "url": "/static/js/44.5b205199.chunk.js"
  },
  {
    "revision": "1a22347bc19756fca4f0",
    "url": "/static/js/45.11ad6cca.chunk.js"
  },
  {
    "revision": "28a663b6bf2f316e4c58",
    "url": "/static/js/46.8ced76a9.chunk.js"
  },
  {
    "revision": "f9fa1cdbef4721c09b20",
    "url": "/static/js/47.fb3d8437.chunk.js"
  },
  {
    "revision": "a79242ce214e61ff875b",
    "url": "/static/js/48.16334224.chunk.js"
  },
  {
    "revision": "e48aa0fc419a0950e1a9",
    "url": "/static/js/49.fc6aecc8.chunk.js"
  },
  {
    "revision": "99191c489995af318733",
    "url": "/static/js/5.bb4eebeb.chunk.js"
  },
  {
    "revision": "c5896d2e2c8f1bfe390e",
    "url": "/static/js/50.9401b0cd.chunk.js"
  },
  {
    "revision": "0759e09f432b97477cfa",
    "url": "/static/js/51.1aa09074.chunk.js"
  },
  {
    "revision": "52f6f43b54f3ca285cb9",
    "url": "/static/js/52.5f505a9b.chunk.js"
  },
  {
    "revision": "9572d9b4ac45a841e1cf",
    "url": "/static/js/53.b6105146.chunk.js"
  },
  {
    "revision": "80249d560c925ca576e7",
    "url": "/static/js/54.d444f332.chunk.js"
  },
  {
    "revision": "7e63d57c5c329102a690",
    "url": "/static/js/55.b72021e1.chunk.js"
  },
  {
    "revision": "67589a115611286387c8",
    "url": "/static/js/56.836d1039.chunk.js"
  },
  {
    "revision": "1f01f76fa5ce1ad8a591",
    "url": "/static/js/57.4b92c27d.chunk.js"
  },
  {
    "revision": "8af86f4b3b3c76c6d774",
    "url": "/static/js/58.4d2f3384.chunk.js"
  },
  {
    "revision": "805afad2c3699c519b0c",
    "url": "/static/js/59.45c78d52.chunk.js"
  },
  {
    "revision": "35593e3fdc0a3f287048",
    "url": "/static/js/6.45856e6c.chunk.js"
  },
  {
    "revision": "4d7461336606ad36b415",
    "url": "/static/js/60.52188952.chunk.js"
  },
  {
    "revision": "8555196283dcfb6d356f",
    "url": "/static/js/61.9dc370a7.chunk.js"
  },
  {
    "revision": "85b637b3880c8606f1e1",
    "url": "/static/js/62.626080c0.chunk.js"
  },
  {
    "revision": "ca6c9d3f07ff86fd17c5",
    "url": "/static/js/63.967bab31.chunk.js"
  },
  {
    "revision": "a1acada4f85efde1e955",
    "url": "/static/js/64.494828bd.chunk.js"
  },
  {
    "revision": "9a725450950c1f044c54",
    "url": "/static/js/65.47a9cbe3.chunk.js"
  },
  {
    "revision": "036cb771d795c14dbf10",
    "url": "/static/js/66.efc9eb04.chunk.js"
  },
  {
    "revision": "6a4b20a9c47046bf0aa3",
    "url": "/static/js/67.4a46aa9f.chunk.js"
  },
  {
    "revision": "d9cc59944dffd3d62240",
    "url": "/static/js/68.ae6828e9.chunk.js"
  },
  {
    "revision": "08779879b89c9cd89071",
    "url": "/static/js/69.b0b4435f.chunk.js"
  },
  {
    "revision": "10b6ea8265e7c9b37c07",
    "url": "/static/js/7.e9449432.chunk.js"
  },
  {
    "revision": "da701a22990a6eda5bd1",
    "url": "/static/js/70.1907e879.chunk.js"
  },
  {
    "revision": "5783a0cc84c4e121d947",
    "url": "/static/js/71.b38df055.chunk.js"
  },
  {
    "revision": "6554d2ca18ef16945d1e",
    "url": "/static/js/72.f8e01684.chunk.js"
  },
  {
    "revision": "76d96bdd08a581736fa4",
    "url": "/static/js/73.df482fa6.chunk.js"
  },
  {
    "revision": "7566d94b8378f0ef20b5",
    "url": "/static/js/74.10c3040f.chunk.js"
  },
  {
    "revision": "91e9e5a06f83f31e828e",
    "url": "/static/js/75.e0504f61.chunk.js"
  },
  {
    "revision": "100083336518ef5e785a",
    "url": "/static/js/76.ba54b903.chunk.js"
  },
  {
    "revision": "c4a99417ac9a2caa234f",
    "url": "/static/js/77.dae67a15.chunk.js"
  },
  {
    "revision": "990caba6fc7c227f77e4",
    "url": "/static/js/78.0c24fe55.chunk.js"
  },
  {
    "revision": "1699c9a8ed5e009d3971",
    "url": "/static/js/8.64ee7604.chunk.js"
  },
  {
    "revision": "9c8b1ac8177e28038c91",
    "url": "/static/js/9.4ea5e587.chunk.js"
  },
  {
    "revision": "037a7c54fd03479ca6a5",
    "url": "/static/js/main.ebc7cf40.chunk.js"
  },
  {
    "revision": "b6e6410576fec7c47550",
    "url": "/static/js/runtime-main.f5251e45.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);