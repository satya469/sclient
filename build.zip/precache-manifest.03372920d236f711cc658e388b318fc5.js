self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1288c1304e9556872987ce58720ca318",
    "url": "/index.html"
  },
  {
    "revision": "047faed4aacfb040b01c",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "eb609c321e7874ac5f99",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "c65da062aae165d199ae",
    "url": "/static/css/14.db940404.chunk.css"
  },
  {
    "revision": "b31b338c7c717cac7f88",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "b4ad85bbc4b7ab1804e0",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "047faed4aacfb040b01c",
    "url": "/static/js/0.801d997a.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.801d997a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fc6ae765a2b1f9117950",
    "url": "/static/js/1.3d63dcb2.chunk.js"
  },
  {
    "revision": "eb609c321e7874ac5f99",
    "url": "/static/js/12.c8133e8a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.c8133e8a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "451b6e51dd2a1693d6fd",
    "url": "/static/js/13.ef224323.chunk.js"
  },
  {
    "revision": "c65da062aae165d199ae",
    "url": "/static/js/14.34fc1a06.chunk.js"
  },
  {
    "revision": "b31b338c7c717cac7f88",
    "url": "/static/js/15.6959a325.chunk.js"
  },
  {
    "revision": "aff15edad30687f78d74",
    "url": "/static/js/16.44bf2609.chunk.js"
  },
  {
    "revision": "72108a90a75d1ec35a46",
    "url": "/static/js/17.bad8dd3c.chunk.js"
  },
  {
    "revision": "5acc7094e5cbca04447c",
    "url": "/static/js/18.748aa77a.chunk.js"
  },
  {
    "revision": "413c590bd599aade8789",
    "url": "/static/js/19.22c80817.chunk.js"
  },
  {
    "revision": "4489f296e050805180b3",
    "url": "/static/js/2.04c65c44.chunk.js"
  },
  {
    "revision": "9588ad96d5b511723622",
    "url": "/static/js/20.d93477b9.chunk.js"
  },
  {
    "revision": "42a5696a1dfefc7ab30c",
    "url": "/static/js/21.0b7afb93.chunk.js"
  },
  {
    "revision": "a1c8bb8e56baaac10934",
    "url": "/static/js/22.93a41650.chunk.js"
  },
  {
    "revision": "02ddcb533c13fb2e22c8",
    "url": "/static/js/23.b829d7d9.chunk.js"
  },
  {
    "revision": "6567f9b9f1a0e89e80de",
    "url": "/static/js/24.e5c7d1f6.chunk.js"
  },
  {
    "revision": "9228f96c1d8a556a6e73",
    "url": "/static/js/25.4ad385b8.chunk.js"
  },
  {
    "revision": "41592e4baf91866ea62a",
    "url": "/static/js/26.f158f1dd.chunk.js"
  },
  {
    "revision": "26f5fe77a7d3d683a6cc",
    "url": "/static/js/27.786ad096.chunk.js"
  },
  {
    "revision": "5f421d1cd322026dbf2e",
    "url": "/static/js/28.00d59a31.chunk.js"
  },
  {
    "revision": "075bbc3176002484a580",
    "url": "/static/js/29.932e98b5.chunk.js"
  },
  {
    "revision": "2841a0d13b12d7e5c607",
    "url": "/static/js/3.b5304605.chunk.js"
  },
  {
    "revision": "aef3ea8b0dbf20db70d2",
    "url": "/static/js/30.a7710e16.chunk.js"
  },
  {
    "revision": "070cecc54eaa89ec27fc",
    "url": "/static/js/31.10dbc293.chunk.js"
  },
  {
    "revision": "89fc8bbd9e9ec6dcc4e4",
    "url": "/static/js/32.b8881d53.chunk.js"
  },
  {
    "revision": "247a6ebec8f2b0a837f7",
    "url": "/static/js/33.77d9ee91.chunk.js"
  },
  {
    "revision": "68cf2d91fb3f87ae7788",
    "url": "/static/js/34.e7137747.chunk.js"
  },
  {
    "revision": "c57122c3ce40cd32e4e9",
    "url": "/static/js/35.35ce5ece.chunk.js"
  },
  {
    "revision": "79bc7c3a04b453d01535",
    "url": "/static/js/36.b75cd2a3.chunk.js"
  },
  {
    "revision": "e0fd2a07a0809f9e056f",
    "url": "/static/js/37.3069aad1.chunk.js"
  },
  {
    "revision": "1b9767ac212b83246952",
    "url": "/static/js/38.9c5a68a5.chunk.js"
  },
  {
    "revision": "29b762dfb764a4f4bbd7",
    "url": "/static/js/39.31d2c9b4.chunk.js"
  },
  {
    "revision": "03844dab87f22e762de0",
    "url": "/static/js/4.446a288b.chunk.js"
  },
  {
    "revision": "d2a654cce849e2e4e1d8",
    "url": "/static/js/40.3ebf4a2d.chunk.js"
  },
  {
    "revision": "961b4e6a6d47f1b1e1e8",
    "url": "/static/js/41.83ec5c0e.chunk.js"
  },
  {
    "revision": "8eb66d8d087e7fad2bd0",
    "url": "/static/js/42.bf5f97f6.chunk.js"
  },
  {
    "revision": "b34198eb05dfbadd4c98",
    "url": "/static/js/43.43575ef3.chunk.js"
  },
  {
    "revision": "821d037a2920f12ad67b",
    "url": "/static/js/44.f8bc92af.chunk.js"
  },
  {
    "revision": "ae5f940324fb68bc11b9",
    "url": "/static/js/45.5fb8a67f.chunk.js"
  },
  {
    "revision": "a90a96d4387d380be770",
    "url": "/static/js/46.15d91d1a.chunk.js"
  },
  {
    "revision": "c812771151de67feb513",
    "url": "/static/js/47.149daf34.chunk.js"
  },
  {
    "revision": "e082611ee1e1d923b3c6",
    "url": "/static/js/48.99d5d70f.chunk.js"
  },
  {
    "revision": "5456b547e0d949e3df45",
    "url": "/static/js/49.9a2f9432.chunk.js"
  },
  {
    "revision": "5ca470ce1b6c82f075b4",
    "url": "/static/js/5.09ae0a8c.chunk.js"
  },
  {
    "revision": "6fdd170f6e700f65fb31",
    "url": "/static/js/50.a786707a.chunk.js"
  },
  {
    "revision": "12d37f2132a30b848074",
    "url": "/static/js/51.73d84c97.chunk.js"
  },
  {
    "revision": "5cfa6678d74104cbe586",
    "url": "/static/js/52.e024b920.chunk.js"
  },
  {
    "revision": "895daab8b0c59b389d52",
    "url": "/static/js/53.37a920bc.chunk.js"
  },
  {
    "revision": "54559ef14b83eb9f969c",
    "url": "/static/js/54.f6be3f31.chunk.js"
  },
  {
    "revision": "6f606b85770df4a43898",
    "url": "/static/js/55.db1c1100.chunk.js"
  },
  {
    "revision": "51047524081f15993887",
    "url": "/static/js/56.40c9d514.chunk.js"
  },
  {
    "revision": "65ab9743f866134d1549",
    "url": "/static/js/57.35d19e77.chunk.js"
  },
  {
    "revision": "bcf50e270295b6e90205",
    "url": "/static/js/58.82e18543.chunk.js"
  },
  {
    "revision": "ea0db3d0cca4d9ba348f",
    "url": "/static/js/59.b90a27d2.chunk.js"
  },
  {
    "revision": "aba208f2978bed049857",
    "url": "/static/js/6.6b674eea.chunk.js"
  },
  {
    "revision": "71effd857b2d047758b4",
    "url": "/static/js/60.c1498592.chunk.js"
  },
  {
    "revision": "6d37cf6eabca83a77a52",
    "url": "/static/js/61.87a7507a.chunk.js"
  },
  {
    "revision": "a9c94e7f0425fc9202d1",
    "url": "/static/js/62.50bde9fb.chunk.js"
  },
  {
    "revision": "abb6050d6ad0dce929da",
    "url": "/static/js/63.e19827c0.chunk.js"
  },
  {
    "revision": "a6ec6c2e1fae99d6c53a",
    "url": "/static/js/64.7835cb21.chunk.js"
  },
  {
    "revision": "0ea0d33077cd7293c359",
    "url": "/static/js/65.4637d497.chunk.js"
  },
  {
    "revision": "e24daeeb4785072bf5ef",
    "url": "/static/js/66.0a9f1d9a.chunk.js"
  },
  {
    "revision": "1a77bfeb68cc45bd8e78",
    "url": "/static/js/67.b973b441.chunk.js"
  },
  {
    "revision": "5b65089688336b7d12e1",
    "url": "/static/js/68.4ac9ea8a.chunk.js"
  },
  {
    "revision": "aebe311b9b5be2f9d6ba",
    "url": "/static/js/69.d30401c7.chunk.js"
  },
  {
    "revision": "1cd81b592917e2affbcf",
    "url": "/static/js/7.55fc6f06.chunk.js"
  },
  {
    "revision": "ca1786892d07d50cff19",
    "url": "/static/js/70.0f9cb216.chunk.js"
  },
  {
    "revision": "64906326267eff3d9805",
    "url": "/static/js/71.eaee3378.chunk.js"
  },
  {
    "revision": "3110faab601651a3dc69",
    "url": "/static/js/72.f42f5223.chunk.js"
  },
  {
    "revision": "683b020786ac7e12c3b3",
    "url": "/static/js/73.994143db.chunk.js"
  },
  {
    "revision": "99d9739991ab5dfd976a",
    "url": "/static/js/74.74c4494f.chunk.js"
  },
  {
    "revision": "fd57ce243efd30111151",
    "url": "/static/js/75.349bab78.chunk.js"
  },
  {
    "revision": "6c64852b3495b82db00c",
    "url": "/static/js/76.82bc34ad.chunk.js"
  },
  {
    "revision": "35cf2f8c23fd7faca5de",
    "url": "/static/js/77.c609044c.chunk.js"
  },
  {
    "revision": "6025ac719b87204db267",
    "url": "/static/js/78.b7a7e977.chunk.js"
  },
  {
    "revision": "e29e4ddc30f5635b3ba5",
    "url": "/static/js/79.f0b537d1.chunk.js"
  },
  {
    "revision": "1ad733dbe214aee9236f",
    "url": "/static/js/8.48a10019.chunk.js"
  },
  {
    "revision": "b74cb95d8416acc7fc94",
    "url": "/static/js/80.ceb662fe.chunk.js"
  },
  {
    "revision": "e59fc8ae7cdc8308ad6e",
    "url": "/static/js/9.241f50ec.chunk.js"
  },
  {
    "revision": "b4ad85bbc4b7ab1804e0",
    "url": "/static/js/main.b9077aaf.chunk.js"
  },
  {
    "revision": "6e7c2328dd8492a6ae2b",
    "url": "/static/js/runtime-main.e48ced68.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);