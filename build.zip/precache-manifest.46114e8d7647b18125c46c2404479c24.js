self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2ede2f1344e4c86781c9fd06bb1c760c",
    "url": "/index.html"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "341eb079b9f50901db9c",
    "url": "/static/css/15.2e947bf2.chunk.css"
  },
  {
    "revision": "3e999ff932c9f04ab5f7",
    "url": "/static/css/16.193ff724.chunk.css"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/css/17.ac09eb94.chunk.css"
  },
  {
    "revision": "ce95989476085765ff1c",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/js/0.8a37906c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.8a37906c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a2d834a0ada38fe4b820",
    "url": "/static/js/1.eb6b9722.chunk.js"
  },
  {
    "revision": "a7497953fc2554fdde2d",
    "url": "/static/js/10.edad2ca0.chunk.js"
  },
  {
    "revision": "9cff96e0b57fdcb1c499",
    "url": "/static/js/11.adb36443.chunk.js"
  },
  {
    "revision": "5ab9beaa6c87bbb297d2",
    "url": "/static/js/12.64c2c116.chunk.js"
  },
  {
    "revision": "341eb079b9f50901db9c",
    "url": "/static/js/15.ce27ff06.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/15.ce27ff06.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3e999ff932c9f04ab5f7",
    "url": "/static/js/16.4d270661.chunk.js"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/js/17.65d9ab8e.chunk.js"
  },
  {
    "revision": "400011acec77ad12d947",
    "url": "/static/js/18.4f5d5290.chunk.js"
  },
  {
    "revision": "4afae7ca62d493c13301",
    "url": "/static/js/19.009e4f5f.chunk.js"
  },
  {
    "revision": "b764eae093857b85f420",
    "url": "/static/js/2.69781817.chunk.js"
  },
  {
    "revision": "598b39c3430923bd2b79",
    "url": "/static/js/20.38e6bd36.chunk.js"
  },
  {
    "revision": "9c174de6a2c68e133eaf",
    "url": "/static/js/21.b7e5db72.chunk.js"
  },
  {
    "revision": "47e881e0c5da5e1a6a59",
    "url": "/static/js/22.cd3fa91e.chunk.js"
  },
  {
    "revision": "c2e324e4434212a0fa85",
    "url": "/static/js/23.b3cc6c7a.chunk.js"
  },
  {
    "revision": "794f0b54980693cabe15",
    "url": "/static/js/24.42f5f34b.chunk.js"
  },
  {
    "revision": "6be78564c600472fae1f",
    "url": "/static/js/25.2116612b.chunk.js"
  },
  {
    "revision": "336323dde04e9213a9b0",
    "url": "/static/js/26.2b190924.chunk.js"
  },
  {
    "revision": "17f051d9b97bfe8f8e46",
    "url": "/static/js/27.10c5156a.chunk.js"
  },
  {
    "revision": "c74943de7c894aae68ee",
    "url": "/static/js/28.e01c0b2e.chunk.js"
  },
  {
    "revision": "8a1fb8d7b2aeb3927733",
    "url": "/static/js/29.0b029ef6.chunk.js"
  },
  {
    "revision": "d4a20ec47ad2a1ba1c56",
    "url": "/static/js/3.ba378b14.chunk.js"
  },
  {
    "revision": "fd13fbd5ff133c303a1e",
    "url": "/static/js/30.d21b1c03.chunk.js"
  },
  {
    "revision": "bb008b7a4e4793dad787",
    "url": "/static/js/31.71f7ce93.chunk.js"
  },
  {
    "revision": "5d8be68298b41ee841a6",
    "url": "/static/js/32.82eed501.chunk.js"
  },
  {
    "revision": "c93d8648ae797fe1a3db",
    "url": "/static/js/33.b87fc41a.chunk.js"
  },
  {
    "revision": "5b6f3ed58fc0b44cd3e3",
    "url": "/static/js/34.11e76e3c.chunk.js"
  },
  {
    "revision": "d7a6e4b53824298058b9",
    "url": "/static/js/35.a99bc279.chunk.js"
  },
  {
    "revision": "d6b3f3a60db42a804a3d",
    "url": "/static/js/36.3e92d56f.chunk.js"
  },
  {
    "revision": "7d4a2caa99cb89b7fb39",
    "url": "/static/js/37.0047951b.chunk.js"
  },
  {
    "revision": "83e39ea8270328d0ddcf",
    "url": "/static/js/38.523e910c.chunk.js"
  },
  {
    "revision": "ee282c13664a5a9e2ac6",
    "url": "/static/js/39.98054f3f.chunk.js"
  },
  {
    "revision": "d4da53ae2edabc97b878",
    "url": "/static/js/4.9bfa2c54.chunk.js"
  },
  {
    "revision": "052c6f042e7664449729",
    "url": "/static/js/40.a529a281.chunk.js"
  },
  {
    "revision": "9fd4f05ae1476f687b97",
    "url": "/static/js/41.3ba89baf.chunk.js"
  },
  {
    "revision": "f6d61f5550533fc3e414",
    "url": "/static/js/42.40b16330.chunk.js"
  },
  {
    "revision": "b3b7057031c37472c22f",
    "url": "/static/js/43.2939cf1e.chunk.js"
  },
  {
    "revision": "e064e1cd61fcb5e4eb44",
    "url": "/static/js/44.c7a1da35.chunk.js"
  },
  {
    "revision": "671a2f15a84c7886c294",
    "url": "/static/js/45.c8358b01.chunk.js"
  },
  {
    "revision": "c61a24388628fad3f593",
    "url": "/static/js/46.3e13d9c6.chunk.js"
  },
  {
    "revision": "1ff57879aff270a5f990",
    "url": "/static/js/47.05186144.chunk.js"
  },
  {
    "revision": "65f7d4f4ce88674e095d",
    "url": "/static/js/48.ed059002.chunk.js"
  },
  {
    "revision": "58b8f2da81d1daffd30c",
    "url": "/static/js/49.cd201393.chunk.js"
  },
  {
    "revision": "5a524b24de23e3cd8bd6",
    "url": "/static/js/5.597046c0.chunk.js"
  },
  {
    "revision": "776779152d2ff41e3d32",
    "url": "/static/js/50.8ee712c2.chunk.js"
  },
  {
    "revision": "cd897fcf5362da40e494",
    "url": "/static/js/51.18a3512e.chunk.js"
  },
  {
    "revision": "6874ae2b3be5724a1cb7",
    "url": "/static/js/52.475110d0.chunk.js"
  },
  {
    "revision": "4c297de2c0e197d9da2b",
    "url": "/static/js/53.1cf1d321.chunk.js"
  },
  {
    "revision": "7a70b67fef8896be1607",
    "url": "/static/js/54.be8a5ff8.chunk.js"
  },
  {
    "revision": "e0ec4b1e51cfb2058c1b",
    "url": "/static/js/55.f956cf0b.chunk.js"
  },
  {
    "revision": "396c4e6dbda3fd337d52",
    "url": "/static/js/56.685f8d86.chunk.js"
  },
  {
    "revision": "ca1a2a333e90a2e58584",
    "url": "/static/js/57.e5c1c38e.chunk.js"
  },
  {
    "revision": "12005e8bd8192a706a69",
    "url": "/static/js/58.0f5aacd8.chunk.js"
  },
  {
    "revision": "18a0a9a66551c2aae255",
    "url": "/static/js/59.63805255.chunk.js"
  },
  {
    "revision": "03dd504a320760dbd515",
    "url": "/static/js/6.62964cdd.chunk.js"
  },
  {
    "revision": "0daf90d94b945d2d499b",
    "url": "/static/js/60.e5483387.chunk.js"
  },
  {
    "revision": "39af94ff214444abeb88",
    "url": "/static/js/61.d86dc18d.chunk.js"
  },
  {
    "revision": "4fdb9537ba5ba7099fc8",
    "url": "/static/js/62.b27c3aa6.chunk.js"
  },
  {
    "revision": "10973def97f2ca5e94a8",
    "url": "/static/js/63.c84bd356.chunk.js"
  },
  {
    "revision": "81415110b2a200695115",
    "url": "/static/js/64.11d6dd4e.chunk.js"
  },
  {
    "revision": "80c2d11bd367b148aaa5",
    "url": "/static/js/65.4e9b6288.chunk.js"
  },
  {
    "revision": "93de04f665ecd57edd7a",
    "url": "/static/js/66.c0e7afe7.chunk.js"
  },
  {
    "revision": "dacf94c225cae121bd17",
    "url": "/static/js/67.af643ed6.chunk.js"
  },
  {
    "revision": "68bd467131b159f5cf49",
    "url": "/static/js/68.2d37e4a4.chunk.js"
  },
  {
    "revision": "ee9818473106aef71ff2",
    "url": "/static/js/69.ebd412da.chunk.js"
  },
  {
    "revision": "79b167dad81fa1856d44",
    "url": "/static/js/7.b5f9416c.chunk.js"
  },
  {
    "revision": "bf9cfc366dc563f9e255",
    "url": "/static/js/70.ef44d644.chunk.js"
  },
  {
    "revision": "2f788d23e866c4ea1571",
    "url": "/static/js/71.3909130e.chunk.js"
  },
  {
    "revision": "37dc9bc77174317afe82",
    "url": "/static/js/72.abebae7b.chunk.js"
  },
  {
    "revision": "719ca577d09156a3a08d",
    "url": "/static/js/73.d0178599.chunk.js"
  },
  {
    "revision": "13f8e446e28c2d95a924",
    "url": "/static/js/74.63af6129.chunk.js"
  },
  {
    "revision": "7f1baf8d5bb77734d7ad",
    "url": "/static/js/75.ed6f0167.chunk.js"
  },
  {
    "revision": "262339e99ceb2dae9030",
    "url": "/static/js/76.9cb8aaa4.chunk.js"
  },
  {
    "revision": "ecb1474fb6bae424dddf",
    "url": "/static/js/77.b1d7a049.chunk.js"
  },
  {
    "revision": "277326afd762fdd0a42e",
    "url": "/static/js/78.840e567c.chunk.js"
  },
  {
    "revision": "f6b9e056af89dc952117",
    "url": "/static/js/79.89b35940.chunk.js"
  },
  {
    "revision": "b9168326f511576111c2",
    "url": "/static/js/8.7ef385dc.chunk.js"
  },
  {
    "revision": "ba96e814cac35390da16",
    "url": "/static/js/80.caa05978.chunk.js"
  },
  {
    "revision": "f01caa1adf8aa272bef8",
    "url": "/static/js/81.eea0875f.chunk.js"
  },
  {
    "revision": "50751148b63122041384",
    "url": "/static/js/82.2313a889.chunk.js"
  },
  {
    "revision": "12481288ecd5a61d689b",
    "url": "/static/js/9.73ded0de.chunk.js"
  },
  {
    "revision": "ce95989476085765ff1c",
    "url": "/static/js/main.e42f6fed.chunk.js"
  },
  {
    "revision": "b509c1adf79f438d6b80",
    "url": "/static/js/runtime-main.c7d6070e.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);