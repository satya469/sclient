self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c4fc2aca5834b9469fa0c6dc1c2a89b0",
    "url": "/index.html"
  },
  {
    "revision": "6fad8a4cef9b0a49d39f",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "1f11d146e896c658e576",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "2dba10714511eb1bc1ed",
    "url": "/static/css/14.db940404.chunk.css"
  },
  {
    "revision": "078d96e21cbe98627414",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "185b4270e26dacc37ca6",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "6fad8a4cef9b0a49d39f",
    "url": "/static/js/0.fda493c5.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.fda493c5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8d1a7ad728c4863cc118",
    "url": "/static/js/1.cc2c9448.chunk.js"
  },
  {
    "revision": "1f11d146e896c658e576",
    "url": "/static/js/12.0a0e7bd7.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.0a0e7bd7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0989850a709d5cc238e7",
    "url": "/static/js/13.da829a56.chunk.js"
  },
  {
    "revision": "2dba10714511eb1bc1ed",
    "url": "/static/js/14.724d6eb4.chunk.js"
  },
  {
    "revision": "078d96e21cbe98627414",
    "url": "/static/js/15.34acd177.chunk.js"
  },
  {
    "revision": "b91b9b204e6d6046e12c",
    "url": "/static/js/16.18d45c95.chunk.js"
  },
  {
    "revision": "3c2b18985bfe3e03c42e",
    "url": "/static/js/17.72ae0583.chunk.js"
  },
  {
    "revision": "049cd0fbc233181604d3",
    "url": "/static/js/18.3492ea58.chunk.js"
  },
  {
    "revision": "818ce153bacb95d22358",
    "url": "/static/js/19.b9bdad96.chunk.js"
  },
  {
    "revision": "abbb06ca1091ca98565d",
    "url": "/static/js/2.4a1ce132.chunk.js"
  },
  {
    "revision": "ad5b765dc947034ccce0",
    "url": "/static/js/20.41dd26db.chunk.js"
  },
  {
    "revision": "4c4aa9a6e1875d120c6e",
    "url": "/static/js/21.a93dac10.chunk.js"
  },
  {
    "revision": "5b8051d6c59fd7f90021",
    "url": "/static/js/22.534d2d59.chunk.js"
  },
  {
    "revision": "86d3b6b10b66d58421db",
    "url": "/static/js/23.dbeea496.chunk.js"
  },
  {
    "revision": "cca7dd4e0485e0eccde3",
    "url": "/static/js/24.3ece96e3.chunk.js"
  },
  {
    "revision": "6df60165471e653b1ac1",
    "url": "/static/js/25.5a0028b2.chunk.js"
  },
  {
    "revision": "08507e0317ecd729762a",
    "url": "/static/js/26.e41a9eb9.chunk.js"
  },
  {
    "revision": "585dbb8293d717a63f4c",
    "url": "/static/js/27.baded4d1.chunk.js"
  },
  {
    "revision": "359278ac3f68b2b89e48",
    "url": "/static/js/28.7744ceb2.chunk.js"
  },
  {
    "revision": "93a119966c6359b568aa",
    "url": "/static/js/29.49107d7c.chunk.js"
  },
  {
    "revision": "2841a0d13b12d7e5c607",
    "url": "/static/js/3.b5304605.chunk.js"
  },
  {
    "revision": "06c09089748b0a328c6c",
    "url": "/static/js/30.61652eed.chunk.js"
  },
  {
    "revision": "f96181a5085f1aec302f",
    "url": "/static/js/31.a79c487b.chunk.js"
  },
  {
    "revision": "4401557caf5d31fec468",
    "url": "/static/js/32.101da331.chunk.js"
  },
  {
    "revision": "4eb74f02cbca5b5d9fb2",
    "url": "/static/js/33.1d6f89a2.chunk.js"
  },
  {
    "revision": "59be6f19b3a19d5ccd45",
    "url": "/static/js/34.66995e7a.chunk.js"
  },
  {
    "revision": "4c1db0afa7a644c26122",
    "url": "/static/js/35.88c03716.chunk.js"
  },
  {
    "revision": "46d160f651fb7febc9d6",
    "url": "/static/js/36.64b1c46a.chunk.js"
  },
  {
    "revision": "6404fb7b3a2297a496cc",
    "url": "/static/js/37.c7c36bd9.chunk.js"
  },
  {
    "revision": "82bb2a854a8f599d97c8",
    "url": "/static/js/38.30a14f5b.chunk.js"
  },
  {
    "revision": "8d5d5ac0c8c9bcdd40b2",
    "url": "/static/js/39.9449a6b0.chunk.js"
  },
  {
    "revision": "47884b0485d5893a57db",
    "url": "/static/js/4.c2503032.chunk.js"
  },
  {
    "revision": "6c9f7950bbd7951e12f6",
    "url": "/static/js/40.de7308b8.chunk.js"
  },
  {
    "revision": "dff52d584424555df782",
    "url": "/static/js/41.912a5546.chunk.js"
  },
  {
    "revision": "49f43dcf35e0756298fb",
    "url": "/static/js/42.83d8d026.chunk.js"
  },
  {
    "revision": "b5a4b2db45bd4a8c62c9",
    "url": "/static/js/43.991e4e0b.chunk.js"
  },
  {
    "revision": "717c2c0e90ea4a1f752d",
    "url": "/static/js/44.eab93ab3.chunk.js"
  },
  {
    "revision": "ae7d02a8400d54ff3787",
    "url": "/static/js/45.64db3d77.chunk.js"
  },
  {
    "revision": "71c3dd8fd393cf204342",
    "url": "/static/js/46.02cbd3ba.chunk.js"
  },
  {
    "revision": "24d09fa8a8057aa70368",
    "url": "/static/js/47.21ab4e70.chunk.js"
  },
  {
    "revision": "9420cb5d77905b772e1d",
    "url": "/static/js/48.77eb8adf.chunk.js"
  },
  {
    "revision": "1199790ff3068a0c59ef",
    "url": "/static/js/49.1e7cab0b.chunk.js"
  },
  {
    "revision": "99191c489995af318733",
    "url": "/static/js/5.bb4eebeb.chunk.js"
  },
  {
    "revision": "4d970a5be84eb24fb805",
    "url": "/static/js/50.ff243936.chunk.js"
  },
  {
    "revision": "4fa9e13ab0deb34b0351",
    "url": "/static/js/51.9e4ba06f.chunk.js"
  },
  {
    "revision": "47b37ae3518840d388d4",
    "url": "/static/js/52.7e3bdd5a.chunk.js"
  },
  {
    "revision": "206eb319fdab0911a23e",
    "url": "/static/js/53.153f4810.chunk.js"
  },
  {
    "revision": "b8a545452effeeb4b9cd",
    "url": "/static/js/54.d31494ec.chunk.js"
  },
  {
    "revision": "19869ab88994895b89f4",
    "url": "/static/js/55.0bbe3bbf.chunk.js"
  },
  {
    "revision": "ee9763d9b35fbb1a3617",
    "url": "/static/js/56.6cb2d385.chunk.js"
  },
  {
    "revision": "a2ca03f7cb9f946491cc",
    "url": "/static/js/57.fd84f4db.chunk.js"
  },
  {
    "revision": "349b691b8265a8527674",
    "url": "/static/js/58.751d0151.chunk.js"
  },
  {
    "revision": "3151908daa6235d6da6e",
    "url": "/static/js/59.33295040.chunk.js"
  },
  {
    "revision": "aba208f2978bed049857",
    "url": "/static/js/6.6b674eea.chunk.js"
  },
  {
    "revision": "175294cb7b2f2e2ac311",
    "url": "/static/js/60.6a7ef12f.chunk.js"
  },
  {
    "revision": "8777bc532ed9e85cefc8",
    "url": "/static/js/61.e6d02b5a.chunk.js"
  },
  {
    "revision": "fec4f2e8b8f96b12ae94",
    "url": "/static/js/62.573d3dc9.chunk.js"
  },
  {
    "revision": "9bbf71b9521053d5dfe5",
    "url": "/static/js/63.738ccd69.chunk.js"
  },
  {
    "revision": "42f8111a54f8d25bb896",
    "url": "/static/js/64.e78702be.chunk.js"
  },
  {
    "revision": "721006aa0ac7bb297c1b",
    "url": "/static/js/65.734e8d0e.chunk.js"
  },
  {
    "revision": "21cdb4d8ebaa8b723d91",
    "url": "/static/js/66.99d7fbcd.chunk.js"
  },
  {
    "revision": "c107a113832c5e84d457",
    "url": "/static/js/67.bc6da0ac.chunk.js"
  },
  {
    "revision": "de64545f34247ee39978",
    "url": "/static/js/68.4c41d6ea.chunk.js"
  },
  {
    "revision": "00c9349300cf1747b935",
    "url": "/static/js/69.fb637df4.chunk.js"
  },
  {
    "revision": "29445532972a213a2245",
    "url": "/static/js/7.6456f54d.chunk.js"
  },
  {
    "revision": "4bbadfe63c786d8bc9f9",
    "url": "/static/js/70.fc1cdb02.chunk.js"
  },
  {
    "revision": "f8f7dc40fb83553a350a",
    "url": "/static/js/71.78a214da.chunk.js"
  },
  {
    "revision": "e87f363fc8f8d2f0a411",
    "url": "/static/js/72.27086472.chunk.js"
  },
  {
    "revision": "3a516200228226864c9c",
    "url": "/static/js/73.80622288.chunk.js"
  },
  {
    "revision": "eddc517390ae56c6e501",
    "url": "/static/js/74.90c1badb.chunk.js"
  },
  {
    "revision": "3c0be33729529b4c4cd3",
    "url": "/static/js/75.74fbc3cc.chunk.js"
  },
  {
    "revision": "321aa07e6ebabc6f856e",
    "url": "/static/js/76.15861d7d.chunk.js"
  },
  {
    "revision": "3764822c048bf64fd48c",
    "url": "/static/js/77.40e726a4.chunk.js"
  },
  {
    "revision": "d80e9ac34593f193f197",
    "url": "/static/js/78.71138994.chunk.js"
  },
  {
    "revision": "d6482c332c325abc89c0",
    "url": "/static/js/79.d7a0ca3d.chunk.js"
  },
  {
    "revision": "05effc3183cb93446a02",
    "url": "/static/js/8.388e99ca.chunk.js"
  },
  {
    "revision": "d8a044593358e87713fa",
    "url": "/static/js/9.ba0c1dc0.chunk.js"
  },
  {
    "revision": "185b4270e26dacc37ca6",
    "url": "/static/js/main.fa0db9bd.chunk.js"
  },
  {
    "revision": "d6ee28fdc1934f36259d",
    "url": "/static/js/runtime-main.044d39d1.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);