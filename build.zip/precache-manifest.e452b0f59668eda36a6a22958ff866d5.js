self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c22c2aacb7fb47efb9a39c058effb9f1",
    "url": "/index.html"
  },
  {
    "revision": "3d839904b74ee27948c3",
    "url": "/static/css/0.483065fd.chunk.css"
  },
  {
    "revision": "6cb4f945b7946bb2f5e4",
    "url": "/static/css/11.16e8e4f6.chunk.css"
  },
  {
    "revision": "7538f8073b7861333329",
    "url": "/static/css/12.4d4b06ea.chunk.css"
  },
  {
    "revision": "1225925c65ebc09a4c64",
    "url": "/static/css/13.c701023d.chunk.css"
  },
  {
    "revision": "9795d5b1e18dc23214c0",
    "url": "/static/css/main.16637cb7.chunk.css"
  },
  {
    "revision": "3d839904b74ee27948c3",
    "url": "/static/js/0.461aefa5.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.461aefa5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b26370ca6e5b3af6d378",
    "url": "/static/js/1.f26d3ec5.chunk.js"
  },
  {
    "revision": "6cb4f945b7946bb2f5e4",
    "url": "/static/js/11.22d4c80a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/11.22d4c80a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7538f8073b7861333329",
    "url": "/static/js/12.46e62c17.chunk.js"
  },
  {
    "revision": "1225925c65ebc09a4c64",
    "url": "/static/js/13.166f3112.chunk.js"
  },
  {
    "revision": "e64e9e376166419e4de1",
    "url": "/static/js/14.8dafd559.chunk.js"
  },
  {
    "revision": "df07051f50f6b39c5fc2",
    "url": "/static/js/15.96fdb09c.chunk.js"
  },
  {
    "revision": "cc964859f31cd2b41cbe",
    "url": "/static/js/16.f9da3d5b.chunk.js"
  },
  {
    "revision": "d4811d98e720bfea8c86",
    "url": "/static/js/17.2e5b28ed.chunk.js"
  },
  {
    "revision": "3ad38f7120eb4e6666ca",
    "url": "/static/js/18.aa1719c4.chunk.js"
  },
  {
    "revision": "49c60ce160aaaee292b9",
    "url": "/static/js/19.c6c929ac.chunk.js"
  },
  {
    "revision": "18cd9d68d370d54cacd3",
    "url": "/static/js/2.459e6c7b.chunk.js"
  },
  {
    "revision": "17e4a078bc76d3029189",
    "url": "/static/js/20.d66b86f7.chunk.js"
  },
  {
    "revision": "14c052242d2c9356beb0",
    "url": "/static/js/21.5cdc8014.chunk.js"
  },
  {
    "revision": "7b4ca044a999954efc8c",
    "url": "/static/js/22.4dbc3570.chunk.js"
  },
  {
    "revision": "497fc98eae0d943f8a8f",
    "url": "/static/js/23.7f34b5f2.chunk.js"
  },
  {
    "revision": "537040c2e320f2f914ad",
    "url": "/static/js/24.94f7885b.chunk.js"
  },
  {
    "revision": "9bd0dc671bc9809f3fa7",
    "url": "/static/js/25.ebdee546.chunk.js"
  },
  {
    "revision": "3007034209ac25570444",
    "url": "/static/js/26.70237cd4.chunk.js"
  },
  {
    "revision": "b5829a71912b863919cd",
    "url": "/static/js/27.421c4323.chunk.js"
  },
  {
    "revision": "041742ff4c7adfb6ab79",
    "url": "/static/js/28.c1ea22c8.chunk.js"
  },
  {
    "revision": "0b9ad88b7e53035e6fcc",
    "url": "/static/js/29.23611128.chunk.js"
  },
  {
    "revision": "6e83d3b0dc2fcc1a97b5",
    "url": "/static/js/3.331a479a.chunk.js"
  },
  {
    "revision": "99e07b9b476b5162e090",
    "url": "/static/js/30.f0922264.chunk.js"
  },
  {
    "revision": "58f42fdce1262e406f50",
    "url": "/static/js/31.992fa27e.chunk.js"
  },
  {
    "revision": "1751169591552c86bca8",
    "url": "/static/js/32.93c4cb86.chunk.js"
  },
  {
    "revision": "82c29ca81273e852b185",
    "url": "/static/js/33.2bced81e.chunk.js"
  },
  {
    "revision": "255b37a73c1596dbf432",
    "url": "/static/js/34.46f5fddd.chunk.js"
  },
  {
    "revision": "ae47b62bef4afae8ab4f",
    "url": "/static/js/35.5de78693.chunk.js"
  },
  {
    "revision": "de09c2442ffe85474b71",
    "url": "/static/js/36.116df08c.chunk.js"
  },
  {
    "revision": "c2115f8e054b81fff6fa",
    "url": "/static/js/37.def013cd.chunk.js"
  },
  {
    "revision": "11968885dd86c953125d",
    "url": "/static/js/38.9629888a.chunk.js"
  },
  {
    "revision": "ee7e1c5318c2d567df74",
    "url": "/static/js/39.cce41fa7.chunk.js"
  },
  {
    "revision": "40c403bcd159e8519498",
    "url": "/static/js/4.68d14411.chunk.js"
  },
  {
    "revision": "ebf00d900603666cdc9e",
    "url": "/static/js/40.c818ae2c.chunk.js"
  },
  {
    "revision": "09fd31fef27c9d8d358e",
    "url": "/static/js/41.4a77b427.chunk.js"
  },
  {
    "revision": "92a3d45a6e3270695fe1",
    "url": "/static/js/42.22e86ed3.chunk.js"
  },
  {
    "revision": "6991e8363d402f22ca30",
    "url": "/static/js/43.e6ee8d9a.chunk.js"
  },
  {
    "revision": "4e1c6b2171babf625a49",
    "url": "/static/js/44.ecd5434b.chunk.js"
  },
  {
    "revision": "03504e025cacd642c796",
    "url": "/static/js/45.6fa4e3bb.chunk.js"
  },
  {
    "revision": "51714d618bc50d4aedff",
    "url": "/static/js/46.b7053cad.chunk.js"
  },
  {
    "revision": "d54ace3475a98e8970bc",
    "url": "/static/js/47.98b16846.chunk.js"
  },
  {
    "revision": "1451fd08e6daf8980bf9",
    "url": "/static/js/48.7bc4b3a7.chunk.js"
  },
  {
    "revision": "2f5a7c5089f9fca68b50",
    "url": "/static/js/49.426cfe82.chunk.js"
  },
  {
    "revision": "87987d2ac38b8c9eda4c",
    "url": "/static/js/5.1223b38c.chunk.js"
  },
  {
    "revision": "9962b1ef85d5fb39cb8d",
    "url": "/static/js/50.8bcf540e.chunk.js"
  },
  {
    "revision": "a7bb96a593580cba5c2a",
    "url": "/static/js/51.3c3cd6ca.chunk.js"
  },
  {
    "revision": "bb453e77b48750a9f546",
    "url": "/static/js/52.bc6c64e2.chunk.js"
  },
  {
    "revision": "bf5a145027e06fc51a71",
    "url": "/static/js/53.85ca52df.chunk.js"
  },
  {
    "revision": "ca4b6e9255e3e1d320df",
    "url": "/static/js/54.552568a3.chunk.js"
  },
  {
    "revision": "122c335f043a14c5f7b7",
    "url": "/static/js/55.52060cb6.chunk.js"
  },
  {
    "revision": "ff39263980a778aef431",
    "url": "/static/js/56.37b3268e.chunk.js"
  },
  {
    "revision": "5a0a774c904b0487347f",
    "url": "/static/js/57.3e1a5f8b.chunk.js"
  },
  {
    "revision": "4529837550b4c9eec803",
    "url": "/static/js/58.e08a2924.chunk.js"
  },
  {
    "revision": "5c3843892580ff5d6c3e",
    "url": "/static/js/59.9a054db8.chunk.js"
  },
  {
    "revision": "ca2328496a777d5724e3",
    "url": "/static/js/6.d1252d2c.chunk.js"
  },
  {
    "revision": "6e1d55345f51d356d973",
    "url": "/static/js/60.b4425537.chunk.js"
  },
  {
    "revision": "e7a6bdf6e160a9effa00",
    "url": "/static/js/61.c956b36d.chunk.js"
  },
  {
    "revision": "ca244f8d53f11cfa892d",
    "url": "/static/js/62.370056cf.chunk.js"
  },
  {
    "revision": "14b16e8403f6e21198c5",
    "url": "/static/js/63.6a86e02e.chunk.js"
  },
  {
    "revision": "8f3cd7d74cc0ff8ad914",
    "url": "/static/js/64.7481be03.chunk.js"
  },
  {
    "revision": "95e55ed2e0be1f040c7b",
    "url": "/static/js/65.3ad6d7ab.chunk.js"
  },
  {
    "revision": "d1d6b0e89c75dfacdbb1",
    "url": "/static/js/66.0fe19cbb.chunk.js"
  },
  {
    "revision": "7b28cd8d687ed24d3a82",
    "url": "/static/js/67.4ffbe307.chunk.js"
  },
  {
    "revision": "2bbd5c810897edeb307a",
    "url": "/static/js/68.4b0e0053.chunk.js"
  },
  {
    "revision": "f44ddf667180e8cb5323",
    "url": "/static/js/69.b4af4bec.chunk.js"
  },
  {
    "revision": "c5102f6f406edba30b62",
    "url": "/static/js/7.39a56a41.chunk.js"
  },
  {
    "revision": "561fd481af6995007261",
    "url": "/static/js/70.d4801abf.chunk.js"
  },
  {
    "revision": "46850943fac408cc81a7",
    "url": "/static/js/71.cdca8935.chunk.js"
  },
  {
    "revision": "c6ad3678a80cea1b3b3d",
    "url": "/static/js/72.c59e0c65.chunk.js"
  },
  {
    "revision": "c18260e5420aba44369f",
    "url": "/static/js/73.9a481e5e.chunk.js"
  },
  {
    "revision": "ccdc546f94713ca5d235",
    "url": "/static/js/74.ca713fa5.chunk.js"
  },
  {
    "revision": "e80dc2f37297c52f84d2",
    "url": "/static/js/75.74796faa.chunk.js"
  },
  {
    "revision": "481f625b40b9d45eac10",
    "url": "/static/js/8.f945c0f8.chunk.js"
  },
  {
    "revision": "9795d5b1e18dc23214c0",
    "url": "/static/js/main.c7e57f68.chunk.js"
  },
  {
    "revision": "cd6dee70a6a5ea46ef7c",
    "url": "/static/js/runtime-main.6176a4fb.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);