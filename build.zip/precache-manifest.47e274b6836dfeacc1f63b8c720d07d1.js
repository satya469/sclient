self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a07dc02f934d1fcca20adc4951ba1248",
    "url": "/index.html"
  },
  {
    "revision": "20d398cc7457cc3a2e13",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "44f83be1fddf9c79f78e",
    "url": "/static/css/14.2e947bf2.chunk.css"
  },
  {
    "revision": "9fff21c149b423480847",
    "url": "/static/css/15.ff692b3f.chunk.css"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/css/16.ac09eb94.chunk.css"
  },
  {
    "revision": "fe8ed4bedf164b3bf4b0",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "20d398cc7457cc3a2e13",
    "url": "/static/js/0.ac4d5999.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.ac4d5999.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4ca420434cdfb041e876",
    "url": "/static/js/1.bdf4bd53.chunk.js"
  },
  {
    "revision": "a976a6c08f459efd6a1c",
    "url": "/static/js/10.cee5fa87.chunk.js"
  },
  {
    "revision": "ecc4123492b9bdb93e05",
    "url": "/static/js/11.e2ac16c8.chunk.js"
  },
  {
    "revision": "44f83be1fddf9c79f78e",
    "url": "/static/js/14.0d92eb93.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/14.0d92eb93.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9fff21c149b423480847",
    "url": "/static/js/15.8bc86668.chunk.js"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/js/16.f15a0d88.chunk.js"
  },
  {
    "revision": "052fe7e95b31755f5799",
    "url": "/static/js/17.83a01444.chunk.js"
  },
  {
    "revision": "15063e6d1467663110a6",
    "url": "/static/js/18.f94d6905.chunk.js"
  },
  {
    "revision": "8a0500b4549305c91865",
    "url": "/static/js/19.1b8b4684.chunk.js"
  },
  {
    "revision": "7a7bfd5956ed39afbe2b",
    "url": "/static/js/2.0d665ad9.chunk.js"
  },
  {
    "revision": "a1f9334ac162dedaa38f",
    "url": "/static/js/20.6e63de0b.chunk.js"
  },
  {
    "revision": "5cc504cbcbe225da1873",
    "url": "/static/js/21.5f547fcf.chunk.js"
  },
  {
    "revision": "c754f82e8bcb7997ecc2",
    "url": "/static/js/22.c621e381.chunk.js"
  },
  {
    "revision": "4b153979b0ed7c776e91",
    "url": "/static/js/23.fc01054d.chunk.js"
  },
  {
    "revision": "0b12676790919558142a",
    "url": "/static/js/24.f7d1afed.chunk.js"
  },
  {
    "revision": "1e3a57c04138f3202440",
    "url": "/static/js/25.8c01c5eb.chunk.js"
  },
  {
    "revision": "28e61cb9d511acb07c19",
    "url": "/static/js/26.1689280e.chunk.js"
  },
  {
    "revision": "ad9e23f47cc1bed65445",
    "url": "/static/js/27.b5d60313.chunk.js"
  },
  {
    "revision": "791e53c08031001c57c5",
    "url": "/static/js/28.b27fb363.chunk.js"
  },
  {
    "revision": "a1669d66026e2f6e1090",
    "url": "/static/js/29.bb6b579c.chunk.js"
  },
  {
    "revision": "184f408c236edc3cf2f4",
    "url": "/static/js/3.24d99457.chunk.js"
  },
  {
    "revision": "d5f0193c59d397c3f89d",
    "url": "/static/js/30.a6451673.chunk.js"
  },
  {
    "revision": "5f07400c61a183382dd7",
    "url": "/static/js/31.607655a8.chunk.js"
  },
  {
    "revision": "8111134edd17ae9375cd",
    "url": "/static/js/32.fd778575.chunk.js"
  },
  {
    "revision": "917bb0c161279ed0cc27",
    "url": "/static/js/33.f3d95cce.chunk.js"
  },
  {
    "revision": "09ef4b7edcf6235575c3",
    "url": "/static/js/34.fc0a311e.chunk.js"
  },
  {
    "revision": "02218704da2c376eb078",
    "url": "/static/js/35.36f5c495.chunk.js"
  },
  {
    "revision": "86756f14270c35f72633",
    "url": "/static/js/36.4ec14947.chunk.js"
  },
  {
    "revision": "aa89ff496f9c05a4a877",
    "url": "/static/js/37.bc76ddcb.chunk.js"
  },
  {
    "revision": "c5fec0f7826e51bf27a3",
    "url": "/static/js/38.25598aa3.chunk.js"
  },
  {
    "revision": "0f3daa56b11d71eb711e",
    "url": "/static/js/39.03fa538c.chunk.js"
  },
  {
    "revision": "bad7bd47bfbd4a2c47a7",
    "url": "/static/js/4.b1bfe07a.chunk.js"
  },
  {
    "revision": "f6cd6aec4024c296dce5",
    "url": "/static/js/40.f1f7bbbc.chunk.js"
  },
  {
    "revision": "d501ffd5a3c02d5010a2",
    "url": "/static/js/41.bd661a19.chunk.js"
  },
  {
    "revision": "7ab90b565eeb8d796088",
    "url": "/static/js/42.156d63b8.chunk.js"
  },
  {
    "revision": "8e6fc2b14a6a8d0bfa1e",
    "url": "/static/js/43.b1595f84.chunk.js"
  },
  {
    "revision": "9f692001d83913b99ae6",
    "url": "/static/js/44.299823b7.chunk.js"
  },
  {
    "revision": "79e42c014e8ca2191250",
    "url": "/static/js/45.915e7253.chunk.js"
  },
  {
    "revision": "272c5a71756a2913ad72",
    "url": "/static/js/46.870ba967.chunk.js"
  },
  {
    "revision": "3d79d574acbf39a47c44",
    "url": "/static/js/47.4cb99b0a.chunk.js"
  },
  {
    "revision": "2e5ff4da11bebf565839",
    "url": "/static/js/48.aeb6c9b1.chunk.js"
  },
  {
    "revision": "763be9297994a85b9c5f",
    "url": "/static/js/49.7f90875a.chunk.js"
  },
  {
    "revision": "2d339ea8f2cc3b58aa9a",
    "url": "/static/js/5.079becb4.chunk.js"
  },
  {
    "revision": "71da200637386d8de805",
    "url": "/static/js/50.61fd6998.chunk.js"
  },
  {
    "revision": "1d32b879918cfa9f7f8e",
    "url": "/static/js/51.b86ffe7f.chunk.js"
  },
  {
    "revision": "2cbe91626afab06ae64e",
    "url": "/static/js/52.e073c84b.chunk.js"
  },
  {
    "revision": "89149f50c79424407827",
    "url": "/static/js/53.e62fd7ba.chunk.js"
  },
  {
    "revision": "17d929246abd58bae190",
    "url": "/static/js/54.9bf9b815.chunk.js"
  },
  {
    "revision": "94aeae65b7dca28084e3",
    "url": "/static/js/55.e631118c.chunk.js"
  },
  {
    "revision": "826aaadf609e9f564d44",
    "url": "/static/js/56.2cbcf094.chunk.js"
  },
  {
    "revision": "03926255f8c21f6405ea",
    "url": "/static/js/57.6cff20d5.chunk.js"
  },
  {
    "revision": "06518e8623c7bc5d3836",
    "url": "/static/js/58.73173a47.chunk.js"
  },
  {
    "revision": "305bdb240e0bd078a396",
    "url": "/static/js/59.155404c4.chunk.js"
  },
  {
    "revision": "10cfa03396d395386ae1",
    "url": "/static/js/6.75c7ec06.chunk.js"
  },
  {
    "revision": "dc72e53c56e08b340d2b",
    "url": "/static/js/60.fe7309c1.chunk.js"
  },
  {
    "revision": "dfe986cb0470df47fdfe",
    "url": "/static/js/61.86db40ed.chunk.js"
  },
  {
    "revision": "87a848bbcaaa0b826736",
    "url": "/static/js/62.eeec2631.chunk.js"
  },
  {
    "revision": "7400b614aaf59a089b00",
    "url": "/static/js/63.2a89549e.chunk.js"
  },
  {
    "revision": "d4daa242656d63ad9937",
    "url": "/static/js/64.fb24a3ec.chunk.js"
  },
  {
    "revision": "8c2d732b3f73f13209a4",
    "url": "/static/js/65.23fea453.chunk.js"
  },
  {
    "revision": "6e1e943c7d3e1c16feb8",
    "url": "/static/js/66.97797f25.chunk.js"
  },
  {
    "revision": "6d7d5847fbd0e0691c14",
    "url": "/static/js/67.5ad551a2.chunk.js"
  },
  {
    "revision": "001366fe720a71b66ed4",
    "url": "/static/js/68.da8d9e88.chunk.js"
  },
  {
    "revision": "aef38e84af338fd6b918",
    "url": "/static/js/69.df8e1ed1.chunk.js"
  },
  {
    "revision": "848bb95090ba3879ca20",
    "url": "/static/js/7.cd5532ed.chunk.js"
  },
  {
    "revision": "1acfd3297f28fdd77b82",
    "url": "/static/js/70.93d46188.chunk.js"
  },
  {
    "revision": "6af994207f613906e799",
    "url": "/static/js/71.e4e094bc.chunk.js"
  },
  {
    "revision": "effa08a3f1babd1461bc",
    "url": "/static/js/72.96c68c39.chunk.js"
  },
  {
    "revision": "be716b3c2cec8b14a6c3",
    "url": "/static/js/73.a89d45cb.chunk.js"
  },
  {
    "revision": "ff193341c2f54782f8b1",
    "url": "/static/js/74.7ae76bc5.chunk.js"
  },
  {
    "revision": "143935070ec1a7e70bac",
    "url": "/static/js/75.7a684a72.chunk.js"
  },
  {
    "revision": "f2108db56ea51cc388f6",
    "url": "/static/js/76.dbd99209.chunk.js"
  },
  {
    "revision": "f61e4c917ce6020aac06",
    "url": "/static/js/77.b49f3716.chunk.js"
  },
  {
    "revision": "8ba0be8980f847f4e9d5",
    "url": "/static/js/78.9564fc24.chunk.js"
  },
  {
    "revision": "b3e9bfcfb0e5920d69ac",
    "url": "/static/js/79.f0b08295.chunk.js"
  },
  {
    "revision": "264467d8a2ec61582e9a",
    "url": "/static/js/8.d892af14.chunk.js"
  },
  {
    "revision": "76dcdff1996fd0d96392",
    "url": "/static/js/80.95bfd030.chunk.js"
  },
  {
    "revision": "c48a41f2a0e8fd722758",
    "url": "/static/js/81.d8c53389.chunk.js"
  },
  {
    "revision": "b2f0c93d571871dc2263",
    "url": "/static/js/9.582d3ea8.chunk.js"
  },
  {
    "revision": "fe8ed4bedf164b3bf4b0",
    "url": "/static/js/main.615e3c6b.chunk.js"
  },
  {
    "revision": "79a1019a3338fb662d92",
    "url": "/static/js/runtime-main.b78c63ce.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);