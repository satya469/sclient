self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d4b8607a6b99be12d2c4f19a43192850",
    "url": "/index.html"
  },
  {
    "revision": "608f583693241745e7bd",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "0cf050ac461b8881c2f6",
    "url": "/static/css/11.2e947bf2.chunk.css"
  },
  {
    "revision": "ef7d0651611c82552d98",
    "url": "/static/css/12.898aa17c.chunk.css"
  },
  {
    "revision": "013808544117ea3b1a49",
    "url": "/static/css/13.ac09eb94.chunk.css"
  },
  {
    "revision": "88868d32e056465ba609",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "608f583693241745e7bd",
    "url": "/static/js/0.461aefa5.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.461aefa5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b26370ca6e5b3af6d378",
    "url": "/static/js/1.f26d3ec5.chunk.js"
  },
  {
    "revision": "0cf050ac461b8881c2f6",
    "url": "/static/js/11.22d4c80a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/11.22d4c80a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ef7d0651611c82552d98",
    "url": "/static/js/12.a883de26.chunk.js"
  },
  {
    "revision": "013808544117ea3b1a49",
    "url": "/static/js/13.166f3112.chunk.js"
  },
  {
    "revision": "efd9b2099bc17b0edb63",
    "url": "/static/js/14.498eab46.chunk.js"
  },
  {
    "revision": "4dd419aa273822b322e9",
    "url": "/static/js/15.f5f7e459.chunk.js"
  },
  {
    "revision": "cc964859f31cd2b41cbe",
    "url": "/static/js/16.f9da3d5b.chunk.js"
  },
  {
    "revision": "d4811d98e720bfea8c86",
    "url": "/static/js/17.2e5b28ed.chunk.js"
  },
  {
    "revision": "3ad38f7120eb4e6666ca",
    "url": "/static/js/18.aa1719c4.chunk.js"
  },
  {
    "revision": "49c60ce160aaaee292b9",
    "url": "/static/js/19.c6c929ac.chunk.js"
  },
  {
    "revision": "18cd9d68d370d54cacd3",
    "url": "/static/js/2.459e6c7b.chunk.js"
  },
  {
    "revision": "6e240938624148f7c8cb",
    "url": "/static/js/20.fdce27da.chunk.js"
  },
  {
    "revision": "b623fad8d757dd2d2b83",
    "url": "/static/js/21.15b2d283.chunk.js"
  },
  {
    "revision": "70d83b1415a188827614",
    "url": "/static/js/22.4cd5036f.chunk.js"
  },
  {
    "revision": "497fc98eae0d943f8a8f",
    "url": "/static/js/23.7f34b5f2.chunk.js"
  },
  {
    "revision": "9221b59a86e118bab65a",
    "url": "/static/js/24.2c70cb2c.chunk.js"
  },
  {
    "revision": "8b56159d09f595d3f0d2",
    "url": "/static/js/25.b71aa481.chunk.js"
  },
  {
    "revision": "660154106e15a85c922c",
    "url": "/static/js/26.3637afee.chunk.js"
  },
  {
    "revision": "b5829a71912b863919cd",
    "url": "/static/js/27.421c4323.chunk.js"
  },
  {
    "revision": "dd547c8fb0ef6a601719",
    "url": "/static/js/28.1b4a74ba.chunk.js"
  },
  {
    "revision": "0b9ad88b7e53035e6fcc",
    "url": "/static/js/29.23611128.chunk.js"
  },
  {
    "revision": "6e83d3b0dc2fcc1a97b5",
    "url": "/static/js/3.331a479a.chunk.js"
  },
  {
    "revision": "99e07b9b476b5162e090",
    "url": "/static/js/30.f0922264.chunk.js"
  },
  {
    "revision": "58f42fdce1262e406f50",
    "url": "/static/js/31.992fa27e.chunk.js"
  },
  {
    "revision": "bbd78b3a5aa7a84c510d",
    "url": "/static/js/32.e5b896ca.chunk.js"
  },
  {
    "revision": "a052f9ff0203c9b1d288",
    "url": "/static/js/33.d3a53a46.chunk.js"
  },
  {
    "revision": "255b37a73c1596dbf432",
    "url": "/static/js/34.46f5fddd.chunk.js"
  },
  {
    "revision": "ae47b62bef4afae8ab4f",
    "url": "/static/js/35.5de78693.chunk.js"
  },
  {
    "revision": "de09c2442ffe85474b71",
    "url": "/static/js/36.116df08c.chunk.js"
  },
  {
    "revision": "c2115f8e054b81fff6fa",
    "url": "/static/js/37.def013cd.chunk.js"
  },
  {
    "revision": "11968885dd86c953125d",
    "url": "/static/js/38.9629888a.chunk.js"
  },
  {
    "revision": "ee7e1c5318c2d567df74",
    "url": "/static/js/39.cce41fa7.chunk.js"
  },
  {
    "revision": "40c403bcd159e8519498",
    "url": "/static/js/4.68d14411.chunk.js"
  },
  {
    "revision": "ebf00d900603666cdc9e",
    "url": "/static/js/40.c818ae2c.chunk.js"
  },
  {
    "revision": "09fd31fef27c9d8d358e",
    "url": "/static/js/41.4a77b427.chunk.js"
  },
  {
    "revision": "92a3d45a6e3270695fe1",
    "url": "/static/js/42.22e86ed3.chunk.js"
  },
  {
    "revision": "6991e8363d402f22ca30",
    "url": "/static/js/43.e6ee8d9a.chunk.js"
  },
  {
    "revision": "4e1c6b2171babf625a49",
    "url": "/static/js/44.ecd5434b.chunk.js"
  },
  {
    "revision": "2f5fc55a512885292c15",
    "url": "/static/js/45.d7697ba4.chunk.js"
  },
  {
    "revision": "be63a6cf54631083a81a",
    "url": "/static/js/46.4efd5976.chunk.js"
  },
  {
    "revision": "f35901c8a9d842c9eea1",
    "url": "/static/js/47.4d04a7fd.chunk.js"
  },
  {
    "revision": "1451fd08e6daf8980bf9",
    "url": "/static/js/48.7bc4b3a7.chunk.js"
  },
  {
    "revision": "c9dd7220424af21feac1",
    "url": "/static/js/49.e47ab0eb.chunk.js"
  },
  {
    "revision": "87987d2ac38b8c9eda4c",
    "url": "/static/js/5.1223b38c.chunk.js"
  },
  {
    "revision": "9962b1ef85d5fb39cb8d",
    "url": "/static/js/50.8bcf540e.chunk.js"
  },
  {
    "revision": "a7bb96a593580cba5c2a",
    "url": "/static/js/51.3c3cd6ca.chunk.js"
  },
  {
    "revision": "bb453e77b48750a9f546",
    "url": "/static/js/52.bc6c64e2.chunk.js"
  },
  {
    "revision": "bf5a145027e06fc51a71",
    "url": "/static/js/53.85ca52df.chunk.js"
  },
  {
    "revision": "ca4b6e9255e3e1d320df",
    "url": "/static/js/54.552568a3.chunk.js"
  },
  {
    "revision": "122c335f043a14c5f7b7",
    "url": "/static/js/55.52060cb6.chunk.js"
  },
  {
    "revision": "ff39263980a778aef431",
    "url": "/static/js/56.37b3268e.chunk.js"
  },
  {
    "revision": "5a0a774c904b0487347f",
    "url": "/static/js/57.3e1a5f8b.chunk.js"
  },
  {
    "revision": "4529837550b4c9eec803",
    "url": "/static/js/58.e08a2924.chunk.js"
  },
  {
    "revision": "5c3843892580ff5d6c3e",
    "url": "/static/js/59.9a054db8.chunk.js"
  },
  {
    "revision": "d321339caea2c65d1e5c",
    "url": "/static/js/6.bc10560f.chunk.js"
  },
  {
    "revision": "6e1d55345f51d356d973",
    "url": "/static/js/60.b4425537.chunk.js"
  },
  {
    "revision": "e7a6bdf6e160a9effa00",
    "url": "/static/js/61.c956b36d.chunk.js"
  },
  {
    "revision": "d8d66ce26d0773a9bf38",
    "url": "/static/js/62.f7a17855.chunk.js"
  },
  {
    "revision": "3c45e7774028dbde57d7",
    "url": "/static/js/63.fc31f98c.chunk.js"
  },
  {
    "revision": "8f3cd7d74cc0ff8ad914",
    "url": "/static/js/64.7481be03.chunk.js"
  },
  {
    "revision": "95e55ed2e0be1f040c7b",
    "url": "/static/js/65.3ad6d7ab.chunk.js"
  },
  {
    "revision": "d1d6b0e89c75dfacdbb1",
    "url": "/static/js/66.0fe19cbb.chunk.js"
  },
  {
    "revision": "7b28cd8d687ed24d3a82",
    "url": "/static/js/67.4ffbe307.chunk.js"
  },
  {
    "revision": "2bbd5c810897edeb307a",
    "url": "/static/js/68.4b0e0053.chunk.js"
  },
  {
    "revision": "f44ddf667180e8cb5323",
    "url": "/static/js/69.b4af4bec.chunk.js"
  },
  {
    "revision": "a0469d44febf69f00970",
    "url": "/static/js/7.64eeaff7.chunk.js"
  },
  {
    "revision": "561fd481af6995007261",
    "url": "/static/js/70.d4801abf.chunk.js"
  },
  {
    "revision": "46850943fac408cc81a7",
    "url": "/static/js/71.cdca8935.chunk.js"
  },
  {
    "revision": "c6ad3678a80cea1b3b3d",
    "url": "/static/js/72.c59e0c65.chunk.js"
  },
  {
    "revision": "fb75d2385211243090d6",
    "url": "/static/js/73.366f7c0a.chunk.js"
  },
  {
    "revision": "ccdc546f94713ca5d235",
    "url": "/static/js/74.ca713fa5.chunk.js"
  },
  {
    "revision": "d4ad7037292cafbb8a12",
    "url": "/static/js/75.c653c4dd.chunk.js"
  },
  {
    "revision": "481f625b40b9d45eac10",
    "url": "/static/js/8.f945c0f8.chunk.js"
  },
  {
    "revision": "88868d32e056465ba609",
    "url": "/static/js/main.495a45fa.chunk.js"
  },
  {
    "revision": "b3c618c0177d4c385411",
    "url": "/static/js/runtime-main.b11bfa23.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);