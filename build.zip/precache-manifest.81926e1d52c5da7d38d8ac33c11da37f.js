self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5181b54926c6259a5cf9f96e98d3f67e",
    "url": "/index.html"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "dd5137e5fec15b47a616",
    "url": "/static/css/15.2e947bf2.chunk.css"
  },
  {
    "revision": "45c42f140b481cfc19b7",
    "url": "/static/css/16.193ff724.chunk.css"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/css/17.ac09eb94.chunk.css"
  },
  {
    "revision": "7d3c934d9a2beded9aee",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/js/0.8a37906c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.8a37906c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a2d834a0ada38fe4b820",
    "url": "/static/js/1.eb6b9722.chunk.js"
  },
  {
    "revision": "dc480fd5693917d267af",
    "url": "/static/js/10.b1f985da.chunk.js"
  },
  {
    "revision": "8033439c02f0387b6e14",
    "url": "/static/js/11.48bcd008.chunk.js"
  },
  {
    "revision": "60f53328e67e4617348e",
    "url": "/static/js/12.1fd3c7d1.chunk.js"
  },
  {
    "revision": "dd5137e5fec15b47a616",
    "url": "/static/js/15.9f3ab0c6.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/15.9f3ab0c6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "45c42f140b481cfc19b7",
    "url": "/static/js/16.909723c4.chunk.js"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/js/17.65d9ab8e.chunk.js"
  },
  {
    "revision": "655656807c2f9722d291",
    "url": "/static/js/18.c6c5ceae.chunk.js"
  },
  {
    "revision": "01d85538a54d045ecb0c",
    "url": "/static/js/19.34f65e1c.chunk.js"
  },
  {
    "revision": "b764eae093857b85f420",
    "url": "/static/js/2.69781817.chunk.js"
  },
  {
    "revision": "598b39c3430923bd2b79",
    "url": "/static/js/20.38e6bd36.chunk.js"
  },
  {
    "revision": "628113aeecac26730150",
    "url": "/static/js/21.8835b3c3.chunk.js"
  },
  {
    "revision": "03cb05cd116557539ed4",
    "url": "/static/js/22.a46f3453.chunk.js"
  },
  {
    "revision": "c2e324e4434212a0fa85",
    "url": "/static/js/23.b3cc6c7a.chunk.js"
  },
  {
    "revision": "5db42dfaed0ddf497b0f",
    "url": "/static/js/24.e233646d.chunk.js"
  },
  {
    "revision": "4c0cf7b3f3d1c69190f7",
    "url": "/static/js/25.405ac694.chunk.js"
  },
  {
    "revision": "fc0cd9be0517c8e5a6c3",
    "url": "/static/js/26.a2563004.chunk.js"
  },
  {
    "revision": "285070b60d4d6d7a304a",
    "url": "/static/js/27.ae4252b8.chunk.js"
  },
  {
    "revision": "385517943132666b5850",
    "url": "/static/js/28.536674d2.chunk.js"
  },
  {
    "revision": "da41defaaf6822ae4a15",
    "url": "/static/js/29.d75ae227.chunk.js"
  },
  {
    "revision": "d4a20ec47ad2a1ba1c56",
    "url": "/static/js/3.ba378b14.chunk.js"
  },
  {
    "revision": "85ece24b4546dce07cf1",
    "url": "/static/js/30.0d75127b.chunk.js"
  },
  {
    "revision": "c18a12118a9b0e1d8aa1",
    "url": "/static/js/31.6b47adcf.chunk.js"
  },
  {
    "revision": "5d8be68298b41ee841a6",
    "url": "/static/js/32.82eed501.chunk.js"
  },
  {
    "revision": "c93d8648ae797fe1a3db",
    "url": "/static/js/33.b87fc41a.chunk.js"
  },
  {
    "revision": "e81e24c756842822bda0",
    "url": "/static/js/34.0f70c0eb.chunk.js"
  },
  {
    "revision": "ac06fcb1c6db93ad20bd",
    "url": "/static/js/35.a4ca33b9.chunk.js"
  },
  {
    "revision": "e7e9b2376cef581f07f8",
    "url": "/static/js/36.b4c30ab8.chunk.js"
  },
  {
    "revision": "9b59d325025e8704fe06",
    "url": "/static/js/37.1ebb5e79.chunk.js"
  },
  {
    "revision": "65fbfca2913ad1d0d417",
    "url": "/static/js/38.5ceed866.chunk.js"
  },
  {
    "revision": "7758ba662e33fec6bed0",
    "url": "/static/js/39.c5cf9bc0.chunk.js"
  },
  {
    "revision": "d4da53ae2edabc97b878",
    "url": "/static/js/4.9bfa2c54.chunk.js"
  },
  {
    "revision": "2cdc6da4c2ab65b987b1",
    "url": "/static/js/40.d01a6c61.chunk.js"
  },
  {
    "revision": "7bb0229394008ad5981e",
    "url": "/static/js/41.22e8d1ad.chunk.js"
  },
  {
    "revision": "ed962fd67090d8f04fac",
    "url": "/static/js/42.dc2bb3e5.chunk.js"
  },
  {
    "revision": "acfdbf25bcd48967e23c",
    "url": "/static/js/43.315ee5bc.chunk.js"
  },
  {
    "revision": "559f1700a00e38850cc6",
    "url": "/static/js/44.9110e992.chunk.js"
  },
  {
    "revision": "c17cd1242c8ed0a807f6",
    "url": "/static/js/45.28a3953c.chunk.js"
  },
  {
    "revision": "e20f2fd8ac749fd25dee",
    "url": "/static/js/46.6b318a48.chunk.js"
  },
  {
    "revision": "ba1011256053e937b605",
    "url": "/static/js/47.d5a66fd4.chunk.js"
  },
  {
    "revision": "41bfd5cc5668c3fe7265",
    "url": "/static/js/48.f09d4b7b.chunk.js"
  },
  {
    "revision": "ad879f1d09e1693af668",
    "url": "/static/js/49.17499d66.chunk.js"
  },
  {
    "revision": "5a524b24de23e3cd8bd6",
    "url": "/static/js/5.597046c0.chunk.js"
  },
  {
    "revision": "a68816b44cdf95e054af",
    "url": "/static/js/50.9b0b8588.chunk.js"
  },
  {
    "revision": "117d6c10a83c3b6d443f",
    "url": "/static/js/51.8bc2bb12.chunk.js"
  },
  {
    "revision": "465b9d736fe44a1e08cd",
    "url": "/static/js/52.a9b94c89.chunk.js"
  },
  {
    "revision": "cf142947ae49aab623ff",
    "url": "/static/js/53.49d7f200.chunk.js"
  },
  {
    "revision": "28dba3fbda75956717f1",
    "url": "/static/js/54.0b5befe1.chunk.js"
  },
  {
    "revision": "abf2a0a91ba1411e5cbc",
    "url": "/static/js/55.921624b9.chunk.js"
  },
  {
    "revision": "eb5de5b0ff1d03d0ba32",
    "url": "/static/js/56.e6e590ab.chunk.js"
  },
  {
    "revision": "c97b33afd10475c4cc41",
    "url": "/static/js/57.a91ead60.chunk.js"
  },
  {
    "revision": "77428b4f669ca449a485",
    "url": "/static/js/58.1ed2685a.chunk.js"
  },
  {
    "revision": "99e61247c6316818d428",
    "url": "/static/js/59.39f064a9.chunk.js"
  },
  {
    "revision": "03dd504a320760dbd515",
    "url": "/static/js/6.62964cdd.chunk.js"
  },
  {
    "revision": "dc8a6bd44a931d1bfa39",
    "url": "/static/js/60.fd508d65.chunk.js"
  },
  {
    "revision": "39af94ff214444abeb88",
    "url": "/static/js/61.d86dc18d.chunk.js"
  },
  {
    "revision": "4fdb9537ba5ba7099fc8",
    "url": "/static/js/62.b27c3aa6.chunk.js"
  },
  {
    "revision": "10973def97f2ca5e94a8",
    "url": "/static/js/63.c84bd356.chunk.js"
  },
  {
    "revision": "81415110b2a200695115",
    "url": "/static/js/64.11d6dd4e.chunk.js"
  },
  {
    "revision": "80c2d11bd367b148aaa5",
    "url": "/static/js/65.4e9b6288.chunk.js"
  },
  {
    "revision": "a3bee0b1d60632b46d4f",
    "url": "/static/js/66.ee88638f.chunk.js"
  },
  {
    "revision": "eb1ad5507b7c9707c33f",
    "url": "/static/js/67.570a2612.chunk.js"
  },
  {
    "revision": "73f99699466c6a20e646",
    "url": "/static/js/68.09e08a2f.chunk.js"
  },
  {
    "revision": "5f8dd226d74061a62963",
    "url": "/static/js/69.762f16a9.chunk.js"
  },
  {
    "revision": "194d9b07f5c4cb16f7b9",
    "url": "/static/js/7.11a85d78.chunk.js"
  },
  {
    "revision": "119b1f6a21d45327533e",
    "url": "/static/js/70.c70e041e.chunk.js"
  },
  {
    "revision": "2f788d23e866c4ea1571",
    "url": "/static/js/71.3909130e.chunk.js"
  },
  {
    "revision": "37dc9bc77174317afe82",
    "url": "/static/js/72.abebae7b.chunk.js"
  },
  {
    "revision": "9ee9999c5ee3fd1c8b14",
    "url": "/static/js/73.18a9b3ca.chunk.js"
  },
  {
    "revision": "cce8cc481293149eaec6",
    "url": "/static/js/74.b407e347.chunk.js"
  },
  {
    "revision": "7f1baf8d5bb77734d7ad",
    "url": "/static/js/75.ed6f0167.chunk.js"
  },
  {
    "revision": "e4938a59feea74e7c3e7",
    "url": "/static/js/76.116a9a7a.chunk.js"
  },
  {
    "revision": "ecb1474fb6bae424dddf",
    "url": "/static/js/77.b1d7a049.chunk.js"
  },
  {
    "revision": "a0e4da7d95b888c1c9bf",
    "url": "/static/js/78.a2cee0a8.chunk.js"
  },
  {
    "revision": "b85613a86b2270f255c6",
    "url": "/static/js/79.b00de3d7.chunk.js"
  },
  {
    "revision": "2a0274c4ebc88f8daab8",
    "url": "/static/js/8.36cbf1eb.chunk.js"
  },
  {
    "revision": "45b63f26e849237c7f9b",
    "url": "/static/js/80.c2620cc3.chunk.js"
  },
  {
    "revision": "f01caa1adf8aa272bef8",
    "url": "/static/js/81.eea0875f.chunk.js"
  },
  {
    "revision": "22cc4c2e9a883335817f",
    "url": "/static/js/82.03a1f8ed.chunk.js"
  },
  {
    "revision": "9e56e4a21ecf62f95e75",
    "url": "/static/js/9.709e28e1.chunk.js"
  },
  {
    "revision": "7d3c934d9a2beded9aee",
    "url": "/static/js/main.83a07e9e.chunk.js"
  },
  {
    "revision": "217ce26fb9737bc94ceb",
    "url": "/static/js/runtime-main.9cfdcdae.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);