self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "167b25a2cf3dffe96a087c2a21836fdb",
    "url": "/index.html"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "341eb079b9f50901db9c",
    "url": "/static/css/15.2e947bf2.chunk.css"
  },
  {
    "revision": "25ae0a692b5f6d3f6c33",
    "url": "/static/css/16.898aa17c.chunk.css"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/css/17.ac09eb94.chunk.css"
  },
  {
    "revision": "f8a906151f282bdd6e5d",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "36308b888f9ba5f9d125",
    "url": "/static/js/0.8a37906c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.8a37906c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a2d834a0ada38fe4b820",
    "url": "/static/js/1.eb6b9722.chunk.js"
  },
  {
    "revision": "6821dabf4fef82adefbb",
    "url": "/static/js/10.ee38fee8.chunk.js"
  },
  {
    "revision": "f0ab249047d8c6f4a432",
    "url": "/static/js/11.5737808f.chunk.js"
  },
  {
    "revision": "ffa020455973e26049c5",
    "url": "/static/js/12.b2ced178.chunk.js"
  },
  {
    "revision": "341eb079b9f50901db9c",
    "url": "/static/js/15.ce27ff06.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/15.ce27ff06.chunk.js.LICENSE.txt"
  },
  {
    "revision": "25ae0a692b5f6d3f6c33",
    "url": "/static/js/16.e950e8a1.chunk.js"
  },
  {
    "revision": "f82a6fec85e0f5b07df1",
    "url": "/static/js/17.65d9ab8e.chunk.js"
  },
  {
    "revision": "1e1d3282811541b76c43",
    "url": "/static/js/18.b2b89e05.chunk.js"
  },
  {
    "revision": "3b61c7dd8781da6b700b",
    "url": "/static/js/19.33bd4e09.chunk.js"
  },
  {
    "revision": "b764eae093857b85f420",
    "url": "/static/js/2.69781817.chunk.js"
  },
  {
    "revision": "598b39c3430923bd2b79",
    "url": "/static/js/20.38e6bd36.chunk.js"
  },
  {
    "revision": "9c174de6a2c68e133eaf",
    "url": "/static/js/21.b7e5db72.chunk.js"
  },
  {
    "revision": "8415847be8823d6b4745",
    "url": "/static/js/22.12e6214d.chunk.js"
  },
  {
    "revision": "c2e324e4434212a0fa85",
    "url": "/static/js/23.b3cc6c7a.chunk.js"
  },
  {
    "revision": "432bcf102fc1e742b8e3",
    "url": "/static/js/24.88913100.chunk.js"
  },
  {
    "revision": "01603094f3150cc0f3c7",
    "url": "/static/js/25.5253e25d.chunk.js"
  },
  {
    "revision": "81eb189d208016703c31",
    "url": "/static/js/26.a947d887.chunk.js"
  },
  {
    "revision": "f5248474157b17950c39",
    "url": "/static/js/27.aec76441.chunk.js"
  },
  {
    "revision": "933ede8d4d4ff8b2901d",
    "url": "/static/js/28.34b3cd74.chunk.js"
  },
  {
    "revision": "fa251d657362d2877aa8",
    "url": "/static/js/29.b70b876e.chunk.js"
  },
  {
    "revision": "d4a20ec47ad2a1ba1c56",
    "url": "/static/js/3.ba378b14.chunk.js"
  },
  {
    "revision": "5ac4ed2742ac63e5287e",
    "url": "/static/js/30.c992bd89.chunk.js"
  },
  {
    "revision": "24e11776a52f6d54eacb",
    "url": "/static/js/31.249b0b62.chunk.js"
  },
  {
    "revision": "5d8be68298b41ee841a6",
    "url": "/static/js/32.82eed501.chunk.js"
  },
  {
    "revision": "c93d8648ae797fe1a3db",
    "url": "/static/js/33.b87fc41a.chunk.js"
  },
  {
    "revision": "8e8b59fac7f8bc000a19",
    "url": "/static/js/34.27b6e6b9.chunk.js"
  },
  {
    "revision": "49a4d461e46fa024e304",
    "url": "/static/js/35.7954400d.chunk.js"
  },
  {
    "revision": "47bb4abbe90956a1d69a",
    "url": "/static/js/36.9b6a01b3.chunk.js"
  },
  {
    "revision": "1620290acabc09ac9e7e",
    "url": "/static/js/37.18d362a5.chunk.js"
  },
  {
    "revision": "bab377cafe2f346b96a5",
    "url": "/static/js/38.d21d67a9.chunk.js"
  },
  {
    "revision": "7c4b0d182d9afb7d8396",
    "url": "/static/js/39.b02643a3.chunk.js"
  },
  {
    "revision": "d4da53ae2edabc97b878",
    "url": "/static/js/4.9bfa2c54.chunk.js"
  },
  {
    "revision": "46dbdd9325ae5f5041dd",
    "url": "/static/js/40.ebaafa10.chunk.js"
  },
  {
    "revision": "aa4ab6833f70a2f9e20e",
    "url": "/static/js/41.b7272d42.chunk.js"
  },
  {
    "revision": "fc5c1699f7ee7331562d",
    "url": "/static/js/42.5cb1c3ae.chunk.js"
  },
  {
    "revision": "81db4eaf481f7fb002ca",
    "url": "/static/js/43.237e2ce2.chunk.js"
  },
  {
    "revision": "2d710375a964134b81b4",
    "url": "/static/js/44.1ed81b08.chunk.js"
  },
  {
    "revision": "6e9dcd8a9485a33f9fc5",
    "url": "/static/js/45.98a19936.chunk.js"
  },
  {
    "revision": "773b314cfef1f41c641c",
    "url": "/static/js/46.c54b06da.chunk.js"
  },
  {
    "revision": "fbbc7a630f9bda27875a",
    "url": "/static/js/47.7da09dfc.chunk.js"
  },
  {
    "revision": "d34bd4d5b1485304a406",
    "url": "/static/js/48.15ff6576.chunk.js"
  },
  {
    "revision": "fa32f500d9fe9243ffe5",
    "url": "/static/js/49.c9f416c4.chunk.js"
  },
  {
    "revision": "5a524b24de23e3cd8bd6",
    "url": "/static/js/5.597046c0.chunk.js"
  },
  {
    "revision": "df64fa750206f1b1351f",
    "url": "/static/js/50.dd9bae08.chunk.js"
  },
  {
    "revision": "4795f48f2e2033cdb5a4",
    "url": "/static/js/51.528212d5.chunk.js"
  },
  {
    "revision": "b069c28178d5f88c5750",
    "url": "/static/js/52.7133d4e7.chunk.js"
  },
  {
    "revision": "2051363c7552ade67c9d",
    "url": "/static/js/53.99fa541d.chunk.js"
  },
  {
    "revision": "45b2afca63eb2a996fb2",
    "url": "/static/js/54.f5465e0f.chunk.js"
  },
  {
    "revision": "cda35eca18bc2a0dff04",
    "url": "/static/js/55.e64e4a15.chunk.js"
  },
  {
    "revision": "8c17d8549bb67ad844c2",
    "url": "/static/js/56.e7cf2a3c.chunk.js"
  },
  {
    "revision": "beb8690a872e04d1cba8",
    "url": "/static/js/57.40967aa0.chunk.js"
  },
  {
    "revision": "480d81a7547ddb15e52c",
    "url": "/static/js/58.e307212b.chunk.js"
  },
  {
    "revision": "e1df8280a552ccc966c4",
    "url": "/static/js/59.43cc51ad.chunk.js"
  },
  {
    "revision": "03dd504a320760dbd515",
    "url": "/static/js/6.62964cdd.chunk.js"
  },
  {
    "revision": "cff23a5c393bfe9a9871",
    "url": "/static/js/60.d567f675.chunk.js"
  },
  {
    "revision": "39af94ff214444abeb88",
    "url": "/static/js/61.d86dc18d.chunk.js"
  },
  {
    "revision": "4fdb9537ba5ba7099fc8",
    "url": "/static/js/62.b27c3aa6.chunk.js"
  },
  {
    "revision": "10973def97f2ca5e94a8",
    "url": "/static/js/63.c84bd356.chunk.js"
  },
  {
    "revision": "81415110b2a200695115",
    "url": "/static/js/64.11d6dd4e.chunk.js"
  },
  {
    "revision": "80c2d11bd367b148aaa5",
    "url": "/static/js/65.4e9b6288.chunk.js"
  },
  {
    "revision": "eab55dcb4734ea7d625b",
    "url": "/static/js/66.d888ad42.chunk.js"
  },
  {
    "revision": "5088b6c668568d8ae1e5",
    "url": "/static/js/67.9dd1c031.chunk.js"
  },
  {
    "revision": "cecdb56ee3465822f1e7",
    "url": "/static/js/68.720695a0.chunk.js"
  },
  {
    "revision": "21cfacded79fd6660c9f",
    "url": "/static/js/69.b47acf21.chunk.js"
  },
  {
    "revision": "2ac1828c3b279fd0168c",
    "url": "/static/js/7.f4b6bdc1.chunk.js"
  },
  {
    "revision": "e3e6e2dab9db68e43c90",
    "url": "/static/js/70.b77b0385.chunk.js"
  },
  {
    "revision": "2f788d23e866c4ea1571",
    "url": "/static/js/71.3909130e.chunk.js"
  },
  {
    "revision": "37dc9bc77174317afe82",
    "url": "/static/js/72.abebae7b.chunk.js"
  },
  {
    "revision": "62e26436ba7b4317c541",
    "url": "/static/js/73.0b8272fc.chunk.js"
  },
  {
    "revision": "261dcfc9662377a12584",
    "url": "/static/js/74.ad3eb807.chunk.js"
  },
  {
    "revision": "7f1baf8d5bb77734d7ad",
    "url": "/static/js/75.ed6f0167.chunk.js"
  },
  {
    "revision": "880374e2ac480d29e2a5",
    "url": "/static/js/76.b7426337.chunk.js"
  },
  {
    "revision": "ecb1474fb6bae424dddf",
    "url": "/static/js/77.b1d7a049.chunk.js"
  },
  {
    "revision": "e8982dd0deaede91145f",
    "url": "/static/js/78.86a2ae43.chunk.js"
  },
  {
    "revision": "bef048358f5800e78b59",
    "url": "/static/js/79.b1272a50.chunk.js"
  },
  {
    "revision": "1714463c8ff1c5ee5fdb",
    "url": "/static/js/8.23642d53.chunk.js"
  },
  {
    "revision": "e39e961045287fd75737",
    "url": "/static/js/80.e96ed446.chunk.js"
  },
  {
    "revision": "f01caa1adf8aa272bef8",
    "url": "/static/js/81.eea0875f.chunk.js"
  },
  {
    "revision": "b736a9371bd70f51f1bb",
    "url": "/static/js/82.9002d45d.chunk.js"
  },
  {
    "revision": "2a5ab75fb391818d12ad",
    "url": "/static/js/9.88526b34.chunk.js"
  },
  {
    "revision": "f8a906151f282bdd6e5d",
    "url": "/static/js/main.e4f1f25e.chunk.js"
  },
  {
    "revision": "128c37704f5c611faf77",
    "url": "/static/js/runtime-main.93f6d349.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);